package com.store;

import com.store.view.LoginView;
import com.store.model.User;
import com.store.util.SessionManager;
import com.store.view.dashboard.AdminDashboard;
import com.store.view.dashboard.CashierDashboard;
import com.store.view.dashboard.ManagerDashboard;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.geometry.Rectangle2D;
import javafx.scene.layout.StackPane;

public class App extends Application {
    private static Stage primaryStage;
    private static Scene mainScene;
    private static StackPane mainContainer;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("Electronics Store Management System");

        // Initialize main container
        mainContainer = new StackPane();
        mainContainer.getStyleClass().add("main-container");

        // Create main scene with the container
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        mainScene = new Scene(mainContainer, screenBounds.getWidth(), screenBounds.getHeight());
        mainScene.getStylesheets().add("/styles/style.css");

        // Add application icon
        try {
            primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/images/icon.png")));
        } catch (Exception e) {
            System.err.println("Could not load application icon");
        }

        // Configure stage
        primaryStage.setMaximized(true);
        primaryStage.setFullScreen(false);
        primaryStage.setResizable(true);
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);

        // Handle window close request
        primaryStage.setOnCloseRequest(event -> {
            Platform.exit();
            System.exit(0);
        });

        // Set the main scene
        primaryStage.setScene(mainScene);
        showLoginScreen();
        primaryStage.show();

        // Ensure the stage is maximized after showing
        Platform.runLater(() -> {
            primaryStage.setMaximized(true);
            centerContent();
        });
    }

    private static void centerContent() {
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        primaryStage.setX(screenBounds.getMinX());
        primaryStage.setY(screenBounds.getMinY());
        primaryStage.setWidth(screenBounds.getWidth());
        primaryStage.setHeight(screenBounds.getHeight());
    }

    public static void showLoginScreen() {
        Platform.runLater(() -> {
            LoginView loginView = new LoginView();
            mainContainer.getChildren().clear();
            mainContainer.getChildren().add(loginView.getView());
        });
    }

    public static void showDashboard() {
        Platform.runLater(() -> {
            SessionManager sessionManager = SessionManager.getInstance();
            if (!sessionManager.isLoggedIn()) {
                showLoginScreen();
                return;
            }

            User currentUser = sessionManager.getCurrentUser().orElseThrow();
            System.out.println("User role: " + currentUser.getRole());


            switch (currentUser.getRole()) {
                case ADMINISTRATOR:
                    mainContainer.getChildren().clear();
                    mainContainer.getChildren().add(new AdminDashboard(currentUser).getView());
                    break;
                case MANAGER:
                    mainContainer.getChildren().clear();
                    mainContainer.getChildren().add(new ManagerDashboard(currentUser).getView());
                    break;
                case CASHIER:
                    mainContainer.getChildren().clear();
                    mainContainer.getChildren().add(new CashierDashboard(currentUser).getView());
                    break;
            }
        });
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static Scene getMainScene() {
        return mainScene;
    }

    public static void setContent(javafx.scene.Node content) {
        Platform.runLater(() -> {
            mainContainer.getChildren().clear();
            mainContainer.getChildren().add(content);
        });
    }
}