package com.store.controller;

import com.store.model.Bill;
import com.store.model.Item;
import com.store.util.DatabaseUtil;
import com.store.util.FileHandler;
import com.store.util.SessionManager;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class BillController {
    private static BillController instance;
    private final Map<String, Bill> bills;
    private final DatabaseUtil dbUtil;
    private final String BILLS_FILE;
    private final String BILLS_DIRECTORY = "bills/";

    private BillController() {
        this.bills = new HashMap<>();
        this.dbUtil = DatabaseUtil.getInstance();
        this.BILLS_FILE = dbUtil.getPath("bills");
        loadBills();
    }

    public static synchronized BillController getInstance() {
        if (instance == null) {
            instance = instance = new BillController();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadBills() {
        try {
            if (FileHandler.exists(BILLS_FILE)) {
                Map<String, Bill> loadedBills = (Map<String, Bill>) FileHandler.readObject(BILLS_FILE);
                bills.putAll(loadedBills);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveBills() throws IOException {
        FileHandler.writeObject(BILLS_FILE, bills);
    }

    private void saveBillToTextFile(Bill bill) throws IOException {
        String fileName = BILLS_DIRECTORY + bill.getBillNumber() + ".txt";
        FileHandler.createDirectory(BILLS_DIRECTORY);
        FileHandler.writeText(fileName, bill.generatePrintableFormat());
    }

    public Bill createBill() throws IllegalStateException {
        SessionManager sessionManager = SessionManager.getInstance();
        if (!sessionManager.isLoggedIn()) {
            throw new IllegalStateException("No user is logged in");
        }

        UUID cashierId = sessionManager.getCurrentUser()
                .orElseThrow(() -> new IllegalStateException("No user found"))
                .getId();

        Bill newBill = new Bill(cashierId);
        bills.put(newBill.getBillNumber(), newBill);

        try {
            saveBills();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save bill: " + e.getMessage());
        }

        return newBill;
    }

    public void addItemToBill(String billNumber, Item item, int quantity)
            throws IllegalArgumentException, IllegalStateException {
        Bill bill = getBill(billNumber);
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }

        bill.addItem(item, quantity);
        try {
            saveBills();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save bill: " + e.getMessage());
        }
    }

    public void removeItemFromBill(String billNumber, Item item)
            throws IllegalArgumentException, IllegalStateException {
        Bill bill = getBill(billNumber);
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }

        bill.removeItem(item);
        try {
            saveBills();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save bill: " + e.getMessage());
        }
    }

    public void finalizeBill(String billNumber)
            throws IllegalArgumentException, IllegalStateException {
        Bill bill = getBill(billNumber);
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }

        bill.finalizeBill();
        try {
            saveBills();
            saveBillToTextFile(bill);
        } catch (IOException e) {
            throw new RuntimeException("Failed to finalize bill: " + e.getMessage());
        }
    }

    public Bill getBill(String billNumber) {
        return bills.get(billNumber);
    }

    public List<Bill> getAllBills() {
        return new ArrayList<>(bills.values());
    }

    public List<Bill> getBillsByCashier(UUID cashierId) {
        return bills.values().stream()
                .filter(bill -> bill.getCashierId().equals(cashierId))
                .collect(Collectors.toList());
    }

    public List<Bill> getBillsByDateRange(LocalDateTime start, LocalDateTime end) {
        return bills.values().stream()
                .filter(bill -> {
                    LocalDateTime saleDate = bill.getSaleDate();
                    return !saleDate.isBefore(start) && !saleDate.isAfter(end);
                })
                .collect(Collectors.toList());
    }

    public double calculateTotalRevenue(LocalDateTime start, LocalDateTime end) {
        return getBillsByDateRange(start, end).stream()
                .filter(Bill::isFinalized)
                .mapToDouble(Bill::calculateTotal)
                .sum();
    }

    public Map<Item, Integer> getTopSellingItems(int limit) {
        return bills.values().stream()
                .filter(Bill::isFinalized)
                .flatMap(bill -> bill.getItems().entrySet().stream())
                .collect(Collectors.groupingBy(
                        Map.Entry::getKey,
                        Collectors.summingInt(Map.Entry::getValue)
                ))
                .entrySet().stream()
                .sorted(Map.Entry.<Item, Integer>comparingByValue().reversed())
                .limit(limit)
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
    }

    public Map<String, Object> getBillStatistics(LocalDateTime start, LocalDateTime end) {
        List<Bill> periodBills = getBillsByDateRange(start, end);

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalBills", periodBills.size());
        stats.put("totalRevenue", calculateTotalRevenue(start, end));
        stats.put("averageBillValue", periodBills.stream()
                .filter(Bill::isFinalized)
                .mapToDouble(Bill::calculateTotal)
                .average()
                .orElse(0.0));
        stats.put("totalItems", periodBills.stream()
                .flatMap(bill -> bill.getItems().values().stream())
                .mapToInt(Integer::intValue)
                .sum());

        return stats;
    }

    public void deleteBill(String billNumber) throws IllegalArgumentException {
        Bill bill = bills.get(billNumber);
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }
        if (bill.isFinalized()) {
            throw new IllegalArgumentException("Cannot delete finalized bill");
        }

        bills.remove(billNumber);
        try {
            saveBills();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save changes: " + e.getMessage());
        }
    }

    public String printBill(String billNumber) throws IllegalArgumentException {
        Bill bill = getBill(billNumber);
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }
        return bill.generatePrintableFormat();
    }

    public void backup() throws IOException {
        dbUtil.backup(BILLS_FILE);
    }

    public void restore(String backupFile) throws IOException {
        dbUtil.restore(backupFile, BILLS_FILE);
        loadBills();
    }
}