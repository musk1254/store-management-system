package com.store.controller;

import com.store.model.Item;
import com.store.model.Supplier;
import com.store.util.AlertDialog;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class InventoryController {
    private static InventoryController instance;
    private final ItemController itemController;
    private final SupplierController supplierController;
    private static final int DEFAULT_LOW_STOCK_THRESHOLD = 5;
    private Map<String, Integer> categoryThresholds;

    private InventoryController() {
        this.itemController = ItemController.getInstance();
        this.supplierController = SupplierController.getInstance();
        this.categoryThresholds = new HashMap<>();
    }

    public static synchronized InventoryController getInstance() {
        if (instance == null) {
            instance = new InventoryController();
        }
        return instance;
    }

    // Stock Management Methods
    public void addStock(UUID itemId, int quantity, double purchasePrice) throws IOException {
        validatePositiveQuantity(quantity);

        Item item = itemController.getItem(itemId)
                .orElseThrow(() -> new IllegalArgumentException("Item not found"));

        if (!item.isActive()) {
            throw new IllegalArgumentException("Cannot add stock to inactive item");
        }

        if (!item.getSupplier().isActive()) {
            throw new IllegalArgumentException("Cannot add stock from inactive supplier");
        }

        // Update purchase price if it changed
        if (purchasePrice != item.getPurchasePrice()) {
            itemController.updateItem(
                    itemId,
                    null,
                    null,
                    null,
                    purchasePrice,
                    Math.max(purchasePrice * 1.2, item.getSellingPrice()) // Ensure minimum 20% markup
            );
        }

        itemController.updateStock(itemId, quantity);
        supplierController.recordSupplierOrder(item.getSupplier().getId());
    }

    public void removeStock(UUID itemId, int quantity) throws IOException {
        validatePositiveQuantity(quantity);
        Item item = itemController.getItem(itemId)
                .orElseThrow(() -> new IllegalArgumentException("Item not found"));

        if (quantity > item.getQuantity()) {
            throw new IllegalArgumentException("Insufficient stock");
        }

        itemController.updateStock(itemId, -quantity);
    }

    // Category Management
    public void setCategoryThreshold(String category, int threshold) {
        validatePositiveQuantity(threshold);
        categoryThresholds.put(category.toLowerCase(), threshold);
    }

    public int getCategoryThreshold(String category) {
        return categoryThresholds.getOrDefault(category.toLowerCase(), DEFAULT_LOW_STOCK_THRESHOLD);
    }

    // Inventory Analysis
    public List<Item> getLowStockItems() {
        return itemController.getAllItems().stream()
                .filter(item -> {
                    int threshold = getCategoryThreshold(item.getCategory());
                    return item.getQuantity() <= threshold && item.isActive();
                })
                .collect(Collectors.toList());
    }

    public Map<String, Double> getCategoryValues() {
        Map<String, Double> values = new HashMap<>();

        itemController.getAllItems().stream()
                .filter(Item::isActive)
                .forEach(item -> {
                    String category = item.getCategory().toLowerCase();
                    double itemValue = item.getQuantity() * item.getPurchasePrice();
                    values.merge(category, itemValue, Double::sum);
                });

        return values;
    }

    public Map<Supplier, Double> getSupplierValues() {
        Map<Supplier, Double> values = new HashMap<>();

        itemController.getAllItems().stream()
                .filter(Item::isActive)
                .forEach(item -> {
                    double itemValue = item.getQuantity() * item.getPurchasePrice();
                    values.merge(item.getSupplier(), itemValue, Double::sum);
                });

        return values;
    }

    // Reporting Methods
    public Map<String, Object> getInventoryReport() {
        Map<String, Object> report = new HashMap<>();

        // Basic stats
        report.putAll(itemController.getInventoryStats());

        // Category analysis
        report.put("categoryValues", getCategoryValues());

        // Supplier analysis
        report.put("supplierValues", getSupplierValues());

        // Low stock items
        report.put("lowStockItems", getLowStockItems().size());

        return report;
    }

    // Inventory Validation Methods
    private void validatePositiveQuantity(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
    }

    // Bulk Operations
    public void bulkUpdatePrices(Map<UUID, Double> newPrices) throws IOException {
        for (Map.Entry<UUID, Double> entry : newPrices.entrySet()) {
            Item item = itemController.getItem(entry.getKey())
                    .orElseThrow(() -> new IllegalArgumentException("Item not found: " + entry.getKey()));

            if (entry.getValue() <= item.getPurchasePrice()) {
                throw new IllegalArgumentException(
                        "New price must be greater than purchase price for item: " + item.getName()
                );
            }

            itemController.updateItem(
                    item.getId(),
                    null,
                    null,
                    null,
                    item.getPurchasePrice(),
                    entry.getValue()
            );
        }
    }

    public void bulkUpdateCategories(Map<String, String> oldToNewCategory) throws IOException {
        for (Item item : itemController.getAllItems()) {
            String newCategory = oldToNewCategory.get(item.getCategory());
            if (newCategory != null) {
                itemController.updateItem(
                        item.getId(),
                        null,
                        newCategory,
                        null,
                        item.getPurchasePrice(),
                        item.getSellingPrice()
                );
            }
        }
    }

    // Inventory Maintenance
    public void performInventoryMaintenance() throws IOException {
        // Deactivate items from inactive suppliers
        for (Item item : itemController.getActiveItems()) {
            if (!item.getSupplier().isActive()) {
                itemController.deactivateItem(item.getId());
                AlertDialog.showWarning(
                        "Item " + item.getName() + " has been deactivated due to inactive supplier"
                );
            }
        }

        // Check for low stock items
        List<Item> lowStockItems = getLowStockItems();
        if (!lowStockItems.isEmpty()) {
            StringBuilder message = new StringBuilder("Low stock items:\n");
            for (Item item : lowStockItems) {
                message.append(String.format(
                        "- %s (Quantity: %d, Threshold: %d)\n",
                        item.getName(),
                        item.getQuantity(),
                        getCategoryThreshold(item.getCategory())
                ));
            }
            AlertDialog.showWarning(message.toString());
        }
    }

    // Data Synchronization
    public void synchronizeInventory() throws IOException {
        itemController.backup();
        performInventoryMaintenance();
    }
}