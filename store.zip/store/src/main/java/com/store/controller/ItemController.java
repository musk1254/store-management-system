package com.store.controller;

import com.store.model.Item;
import com.store.model.Supplier;
import com.store.util.DatabaseUtil;
import com.store.util.FileHandler;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class ItemController {
    private static ItemController instance;
    private final Map<UUID, Item> items;
    private final DatabaseUtil dbUtil;
    private final SupplierController supplierController;
    private final String ITEM_FILE;

    private ItemController() {
        this.items = new HashMap<>();
        this.dbUtil = DatabaseUtil.getInstance();
        this.supplierController = SupplierController.getInstance();
        this.ITEM_FILE = dbUtil.getPath("items");
        loadItems();
    }

    public static synchronized ItemController getInstance() {
        if (instance == null) {
            instance = new ItemController();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadItems() {
        try {
            if (FileHandler.exists(ITEM_FILE)) {
                Map<UUID, Item> loadedItems = (Map<UUID, Item>) FileHandler.readObject(ITEM_FILE);
                items.putAll(loadedItems);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveItems() throws IOException {
        FileHandler.writeObject(ITEM_FILE, items);
    }

    public Item createItem(String name, String category, UUID supplierId,
                           double purchasePrice, double sellingPrice, int quantity)
            throws IllegalArgumentException, IOException {
        validateItemInput(name, category, supplierId, purchasePrice, sellingPrice, quantity);

        Optional<Supplier> supplierOpt = supplierController.getSupplier(supplierId);
        if (supplierOpt.isEmpty()) {
            throw new IllegalArgumentException("Invalid supplier ID");
        }

        Supplier supplier = supplierOpt.get();
        if (!supplier.isActive()) {
            throw new IllegalArgumentException("Cannot create item with inactive supplier");
        }

        Item item = new Item(name, category, supplier, purchasePrice, sellingPrice, quantity);
        items.put(item.getId(), item);
        saveItems();
        return item;
    }

    private void validateItemInput(String name, String category, UUID supplierId,
                                   double purchasePrice, double sellingPrice, int quantity) {
        List<String> errors = new ArrayList<>();

        if (name == null || name.trim().isEmpty()) {
            errors.add("Name cannot be empty");
        }

        if (category == null || category.trim().isEmpty()) {
            errors.add("Category cannot be empty");
        }

        if (supplierId == null) {
            errors.add("Supplier ID cannot be null");
        }

        if (purchasePrice < 0) {
            errors.add("Purchase price cannot be negative");
        }

        if (sellingPrice < 0) {
            errors.add("Selling price cannot be negative");
        }

        if (sellingPrice <= purchasePrice) {
            errors.add("Selling price must be greater than purchase price");
        }

        if (quantity < 0) {
            errors.add("Quantity cannot be negative");
        }

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("\n", errors));
        }
    }

    public void updateItem(UUID itemId, String name, String category,
                           UUID supplierId, double purchasePrice, double sellingPrice)
            throws IllegalArgumentException, IOException {
        Item item = items.get(itemId);
        if (item == null) {
            throw new IllegalArgumentException("Item not found");
        }

        if (name != null && !name.trim().isEmpty()) {
            item.setName(name);
        }

        if (category != null && !category.trim().isEmpty()) {
            item.setCategory(category);
        }

        if (supplierId != null) {
            Optional<Supplier> supplierOpt = supplierController.getSupplier(supplierId);
            if (supplierOpt.isEmpty()) {
                throw new IllegalArgumentException("Invalid supplier ID");
            }
            item.setSupplier(supplierOpt.get());
        }

        if (purchasePrice >= 0) {
            item.setPurchasePrice(purchasePrice);
        }

        if (sellingPrice >= 0) {
            if (sellingPrice <= item.getPurchasePrice()) {
                throw new IllegalArgumentException("Selling price must be greater than purchase price");
            }
            item.setSellingPrice(sellingPrice);
        }

        saveItems();
    }

    public void updateStock(UUID itemId, int quantityChange) throws IllegalArgumentException, IOException {
        Item item = items.get(itemId);
        if (item == null) {
            throw new IllegalArgumentException("Item not found");
        }

        item.updateStock(quantityChange);
        saveItems();
    }

    public void deactivateItem(UUID itemId) throws IOException {
        Item item = items.get(itemId);
        if (item == null) {
            throw new IllegalArgumentException("Item not found");
        }

        item.setActive(false);
        saveItems();
    }

    public void activateItem(UUID itemId) throws IOException {
        Item item = items.get(itemId);
        if (item == null) {
            throw new IllegalArgumentException("Item not found");
        }

        if (!item.getSupplier().isActive()) {
            throw new IllegalArgumentException("Cannot activate item with inactive supplier");
        }

        item.setActive(true);
        saveItems();
    }

    public Optional<Item> getItem(UUID itemId) {
        return Optional.ofNullable(items.get(itemId));
    }

    public List<Item> getAllItems() {
        return new ArrayList<>(items.values());
    }

    public List<Item> getActiveItems() {
        return items.values().stream()
                .filter(Item::isActive)
                .collect(Collectors.toList());
    }

    public List<Item> searchItems(String query) {
        String searchQuery = query.toLowerCase();
        return items.values().stream()
                .filter(item ->
                        item.getName().toLowerCase().contains(searchQuery) ||
                                item.getCategory().toLowerCase().contains(searchQuery) ||
                                item.getSupplier().getName().toLowerCase().contains(searchQuery))
                .collect(Collectors.toList());
    }

    public List<Item> getItemsByCategory(String category) {
        return items.values().stream()
                .filter(item -> item.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    public List<Item> getItemsBySupplier(UUID supplierId) {
        return items.values().stream()
                .filter(item -> item.getSupplier().getId().equals(supplierId))
                .collect(Collectors.toList());
    }

    public List<Item> getLowStockItems(int threshold) {
        return items.values().stream()
                .filter(item -> item.isActive() && item.getQuantity() <= threshold)
                .collect(Collectors.toList());
    }

    public Map<String, Object> getInventoryStats() {
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalItems", items.size());
        stats.put("activeItems", getActiveItems().size());

        double totalValue = items.values().stream()
                .mapToDouble(item -> item.getQuantity() * item.getPurchasePrice())
                .sum();
        stats.put("totalInventoryValue", totalValue);

        Set<String> categories = items.values().stream()
                .map(Item::getCategory)
                .collect(Collectors.toSet());
        stats.put("totalCategories", categories.size());

        long lowStockItems = getLowStockItems(5).size();
        stats.put("lowStockItems", lowStockItems);

        double totalProfit = items.values().stream()
                .mapToDouble(Item::getProfit)
                .sum();
        stats.put("potentialProfit", totalProfit);

        return stats;
    }

    public void backup() throws IOException {
        dbUtil.backup(ITEM_FILE);
    }

    public void restore(String backupFile) throws IOException {
        dbUtil.restore(backupFile, ITEM_FILE);
        loadItems();
    }
}