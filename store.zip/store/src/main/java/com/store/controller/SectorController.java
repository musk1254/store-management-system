package com.store.controller;

import com.store.model.*;
import com.store.util.*;
import java.io.IOException;
import java.util.*;

public class SectorController {
    private static SectorController instance;
    private final Map<Integer, Sector> sectors;
    private final DatabaseUtil dbUtil;
    private final String SECTOR_FILE;

    private SectorController() {
        this.sectors = new HashMap<>();
        this.dbUtil = DatabaseUtil.getInstance();
        this.SECTOR_FILE = dbUtil.getPath("sectors");
        loadSectors();
    }

    public static synchronized SectorController getInstance() {
        if (instance == null) {
            instance = new SectorController();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadSectors() {
        try {
            if (FileHandler.exists(SECTOR_FILE)) {
                Map<Integer, Sector> loadedSectors = (Map<Integer, Sector>) FileHandler.readObject(SECTOR_FILE);
                sectors.putAll(loadedSectors);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveSectors() throws IOException {
        FileHandler.writeObject(SECTOR_FILE, sectors);
    }

    public Sector createSector(String name, String description) throws IOException {
        int id = generateSectorId();
        Sector sector = new Sector(id, name, description);
        sectors.put(id, sector);
        saveSectors();
        return sector;
    }

    private int generateSectorId() {
        return sectors.isEmpty() ? 1 : Collections.max(sectors.keySet()) + 1;
    }

    public Optional<Sector> getSector(int sectorId) {
        return Optional.ofNullable(sectors.get(sectorId));
    }

    public List<Sector> getAllSectors() {
        return new ArrayList<>(sectors.values());
    }

    public List<Sector> getActiveSectors() {
        return sectors.values().stream()
                .filter(Sector::isActive)
                .toList();
    }

    public void updateSector(int sectorId, String name, String description) throws IOException {
        Sector sector = sectors.get(sectorId);
        if (sector == null) {
            throw new IllegalArgumentException("Sector not found");
        }

        if (name != null && !name.isEmpty()) {
            sector.setName(name);
        }
        if (description != null && !description.isEmpty()) {
            sector.setDescription(description);
        }

        saveSectors();
    }

    public void deactivateSector(int sectorId) throws IOException {
        Sector sector = sectors.get(sectorId);
        if (sector == null) {
            throw new IllegalArgumentException("Sector not found");
        }
        sector.setActive(false);
        saveSectors();
    }

    public void activateSector(int sectorId) throws IOException {
        Sector sector = sectors.get(sectorId);
        if (sector == null) {
            throw new IllegalArgumentException("Sector not found");
        }
        sector.setActive(true);
        saveSectors();
    }

    public void assignCashierToSector(int sectorId, UUID cashierId) throws IOException {
        Sector sector = sectors.get(sectorId);
        if (sector == null) {
            throw new IllegalArgumentException("Sector not found");
        }
        sector.assignCashier(cashierId);
        saveSectors();
    }

    public void assignManagerToSector(int sectorId, UUID managerId) throws IOException {
        Sector sector = sectors.get(sectorId);
        if (sector == null) {
            throw new IllegalArgumentException("Sector not found");
        }
        sector.assignManager(managerId);
        saveSectors();
    }

    public void backup() throws IOException {
        dbUtil.backup(SECTOR_FILE);
    }

    public void restore(String backupFile) throws IOException {
        dbUtil.restore(backupFile, SECTOR_FILE);
        loadSectors();
    }
}