package com.store.controller;

import com.store.model.Supplier;
import com.store.util.DatabaseUtil;
import com.store.util.FileHandler;
import com.store.util.ValidationUtil;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class SupplierController {
    private static SupplierController instance;
    private final Map<UUID, Supplier> suppliers;
    private final DatabaseUtil dbUtil;
    private final String SUPPLIER_FILE;

    private SupplierController() {
        this.suppliers = new HashMap<>();
        this.dbUtil = DatabaseUtil.getInstance();
        this.SUPPLIER_FILE = dbUtil.getPath("suppliers");
        loadSuppliers();
    }

    public static synchronized SupplierController getInstance() {
        if (instance == null) {
            instance = new SupplierController();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadSuppliers() {
        try {
            if (FileHandler.exists(SUPPLIER_FILE)) {
                Map<UUID, Supplier> loadedSuppliers = (Map<UUID, Supplier>) FileHandler.readObject(SUPPLIER_FILE);
                suppliers.putAll(loadedSuppliers);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveSuppliers() throws IOException {
        FileHandler.writeObject(SUPPLIER_FILE, suppliers);
    }

    public Supplier createSupplier(String name, String contact, String email, String address)
            throws IllegalArgumentException, IOException {
        validateSupplierInput(name, contact, email, address);

        // Check if supplier with same email exists
        if (getSupplierByEmail(email).isPresent()) {
            throw new IllegalArgumentException("Supplier with this email already exists");
        }

        Supplier supplier = new Supplier(name, contact, email, address);
        suppliers.put(supplier.getId(), supplier);
        saveSuppliers();
        return supplier;
    }

    private void validateSupplierInput(String name, String contact, String email, String address) {
        List<String> errors = new ArrayList<>();

        if (name == null || name.trim().isEmpty()) {
            errors.add("Name cannot be empty");
        }

        if (contact == null || contact.trim().isEmpty()) {
            errors.add("Contact information cannot be empty");
        }

        if (email == null || !ValidationUtil.isValidEmail(email)) {
            errors.add("Invalid email format");
        }

        if (address == null || address.trim().isEmpty()) {
            errors.add("Address cannot be empty");
        }

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("\n", errors));
        }
    }

    public void updateSupplier(UUID supplierId, String name, String contact, String email, String address)
            throws IllegalArgumentException, IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        // Check if new email conflicts with another supplier
        Optional<Supplier> existingSupplier = getSupplierByEmail(email);
        if (existingSupplier.isPresent() && !existingSupplier.get().getId().equals(supplierId)) {
            throw new IllegalArgumentException("Another supplier with this email already exists");
        }

        supplier.updateDetails(name, contact, email, address);
        saveSuppliers();
    }

    public void addProduct(UUID supplierId, String category, double basePrice)
            throws IllegalArgumentException, IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.addProduct(category, basePrice);
        saveSuppliers();
    }

    public void updatePricing(UUID supplierId, String category, double newPrice)
            throws IllegalArgumentException, IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.updatePricing(category, newPrice);
        saveSuppliers();
    }

    public void removeProduct(UUID supplierId, String category) throws IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.removeProduct(category);
        saveSuppliers();
    }

    public void deactivateSupplier(UUID supplierId) throws IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.setActive(false);
        saveSuppliers();
    }

    public void activateSupplier(UUID supplierId) throws IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.setActive(true);
        saveSuppliers();
    }

    public Optional<Supplier> getSupplier(UUID supplierId) {
        return Optional.ofNullable(suppliers.get(supplierId));
    }

    public Optional<Supplier> getSupplierByEmail(String email) {
        return suppliers.values().stream()
                .filter(supplier -> supplier.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    public List<Supplier> getAllSuppliers() {
        return new ArrayList<>(suppliers.values());
    }

    public List<Supplier> getActiveSuppliers() {
        return suppliers.values().stream()
                .filter(Supplier::isActive)
                .collect(Collectors.toList());
    }

    public List<Supplier> searchSuppliers(String query) {
        String searchQuery = query.toLowerCase();
        return suppliers.values().stream()
                .filter(supplier ->
                        supplier.getName().toLowerCase().contains(searchQuery) ||
                                supplier.getEmail().toLowerCase().contains(searchQuery) ||
                                supplier.getContact().toLowerCase().contains(searchQuery) ||
                                supplier.getAddress().toLowerCase().contains(searchQuery))
                .collect(Collectors.toList());
    }

    public List<Supplier> getSuppliersByCategory(String category) {
        return suppliers.values().stream()
                .filter(supplier -> supplier.getProductCategories().contains(category))
                .collect(Collectors.toList());
    }

    public void recordSupplierOrder(UUID supplierId) throws IOException {
        Supplier supplier = suppliers.get(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found");
        }

        supplier.recordOrder();
        saveSuppliers();
    }

    public Map<String, Object> getSupplierStats() {
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalSuppliers", suppliers.size());
        stats.put("activeSuppliers", getActiveSuppliers().size());

        // Get unique categories across all suppliers
        Set<String> allCategories = suppliers.values().stream()
                .flatMap(s -> s.getProductCategories().stream())
                .collect(Collectors.toSet());
        stats.put("totalCategories", allCategories.size());

        // Get suppliers with recent orders (last 30 days)
        LocalDateTime thirtyDaysAgo = LocalDateTime.now().minusDays(30);
        long recentlyActiveSuppliers = suppliers.values().stream()
                .filter(s -> s.getLastOrderDate() != null &&
                        s.getLastOrderDate().isAfter(thirtyDaysAgo))
                .count();
        stats.put("recentlyActiveSuppliers", recentlyActiveSuppliers);

        return stats;
    }

    public void backup() throws IOException {
        dbUtil.backup(SUPPLIER_FILE);
    }

    public void restore(String backupFile) throws IOException {
        dbUtil.restore(backupFile, SUPPLIER_FILE);
        loadSuppliers();
    }
}