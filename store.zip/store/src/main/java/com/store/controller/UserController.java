// UserController.java
package com.store.controller;

import com.store.model.*;
import com.store.util.*;
import java.io.IOException;
import java.util.*;
import java.security.NoSuchAlgorithmException;

public class UserController {
    private static UserController instance;
    private final Map<UUID, User> users;
    private final DatabaseUtil dbUtil;
    private final ValidationUtil validationUtil;
    private final String USER_FILE;

    private UserController() {
        this.users = new HashMap<>();
        this.dbUtil = DatabaseUtil.getInstance();
        this.USER_FILE = dbUtil.getPath("users");
        this.validationUtil = new ValidationUtil();
        loadUsers();
    }

    public static synchronized UserController getInstance() {
        if (instance == null) {
            instance = new UserController();
        }
        return instance;
    }

    @SuppressWarnings("unchecked")
    private void loadUsers() {
        try {
            if (FileHandler.exists(USER_FILE)) {
                Map<UUID, User> loadedUsers = (Map<UUID, User>) FileHandler.readObject(USER_FILE);
                users.putAll(loadedUsers);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            // Consider throwing a custom exception
        }
    }

    private void saveUsers() throws IOException {
        FileHandler.writeObject(USER_FILE, users);
    }

    public User createUser(String username, String password, String name, String email,
                           String phone, UserRole role, Integer sectorId)
            throws IllegalArgumentException, IOException {
        // Validate inputs
        validateUserInput(username, password, name, email, phone);

        // Check if username already exists
        if (getUserByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }

        // Create user based on role
        User newUser;
        try {
            String hashedPassword = SecurityUtil.hashString(password);

            switch (role) {
                case CASHIER:
                    if (sectorId == null) {
                        throw new IllegalArgumentException("Sector ID required for Cashier");
                    }
                    newUser = new Cashier(username, hashedPassword, name, email, phone, sectorId);
                    break;
                case MANAGER:
                    newUser = new Manager(username, hashedPassword, name, email, phone);
                    break;
                case ADMINISTRATOR:
                    newUser = new Administrator(username, hashedPassword, name, email, phone);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid user role");
            }

            users.put(newUser.getId(), newUser);
            saveUsers();
            System.out.println("User created: " + newUser.getUsername());

            //reload users
            loadUsers();
            return newUser;

        } catch (NoSuchAlgorithmException e) {
            throw new IOException("Error creating user: " + e.getMessage());
        }
    }

    public Optional<User> getUser(UUID userId) {
        return Optional.ofNullable(users.get(userId));
    }

    public Optional<User> getUserByUsername(String username) {
        return users.values().stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst();
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users.values());
    }

    public List<User> getUsersByRole(UserRole role) {
        return users.values().stream()
                .filter(user -> user.getRole() == role)
                .toList();
    }

    public void updateUser(UUID userId, String name, String email, String phone)
            throws IllegalArgumentException, IOException {
        User user = users.get(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        // Validate new data
        if (name != null && !name.isEmpty()) {
            ValidationUtil.validateNotEmpty(name, "Name");
            user.setName(name);
        }
        if (email != null && !email.isEmpty()) {
            if (!ValidationUtil.isValidEmail(email)) {
                throw new IllegalArgumentException("Invalid email format");
            }
            user.setEmail(email);
        }
        if (phone != null && !phone.isEmpty()) {
            if (!ValidationUtil.isValidPhone(phone)) {
                throw new IllegalArgumentException("Invalid phone format");
            }
            user.setPhone(phone);
        }

        saveUsers();
    }

    public void deleteUser(UUID userId) throws IOException {
        if (!users.containsKey(userId)) {
            throw new IllegalArgumentException("User not found");
        }

        // Check if it's the last administrator
        User userToDelete = users.get(userId);
        if (userToDelete.getRole() == UserRole.ADMINISTRATOR &&
                getUsersByRole(UserRole.ADMINISTRATOR).size() <= 1) {
            throw new IllegalArgumentException("Cannot delete the last administrator");
        }

        users.remove(userId);
        saveUsers();
    }

    public void changeUserPassword(UUID userId, String oldPassword, String newPassword)
            throws IllegalArgumentException, IOException {
        User user = users.get(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        try {
            // Validate old password
            if (!SecurityUtil.validatePassword(oldPassword, user.getPassword())) {
                throw new IllegalArgumentException("Incorrect current password");
            }

            // Validate and set new password
            AuthenticationService.getInstance().validatePassword(newPassword);
            user.setPassword(SecurityUtil.hashString(newPassword));
            saveUsers();

        } catch (NoSuchAlgorithmException | InvalidCredentialsException e ) {
            throw new IOException("Error changing password: " + e.getMessage());
        }
    }

    public void deactivateUser(UUID userId) throws IOException {
        User user = users.get(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        // Prevent deactivating the last administrator
        if (user.getRole() == UserRole.ADMINISTRATOR &&
                getUsersByRole(UserRole.ADMINISTRATOR).stream()
                        .filter(User::isActive)
                        .count() <= 1) {
            throw new IllegalArgumentException("Cannot deactivate the last active administrator");
        }

        user.setActive(false);
        saveUsers();
    }

    public void activateUser(UUID userId) throws IOException {
        User user = users.get(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }

        user.setActive(true);
        saveUsers();
    }

    private void validateUserInput(String username, String password, String name,
                                   String email, String phone) {
        List<String> errors = new ArrayList<>();

        if (!ValidationUtil.isValidUsername(username)) {
            errors.add("Invalid username format. Username must be 3-20 characters long and contain only letters, numbers, underscores, or hyphens");
        }

        try {
            AuthenticationService.getInstance().validatePassword(password);
        } catch (InvalidCredentialsException e) {
            errors.add(e.getMessage());
        }

        if (!ValidationUtil.isValidName(name)) {
            errors.add("Invalid name format. Name must be 2-50 characters long and contain only letters, spaces, hyphens, or apostrophes");
        }

        if (!ValidationUtil.isValidEmail(email)) {
            errors.add("Invalid email format");
        }

        if (!ValidationUtil.isValidPhone(phone)) {
            errors.add("Invalid phone number format. Must be 10-15 digits, optionally starting with '+'");
        }

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("\n", errors));
        }
    }

    public boolean authenticateUser(String username, String password) {
        Optional<User> userOpt = getUserByUsername(username);
        if (userOpt.isEmpty()) {
            return false;
        }

        User user = userOpt.get();
        if (!user.isActive()) {
            return false;
        }

        try {
            AuthenticationService.getInstance().authenticate(user, username, password);
            return true;
        } catch (InvalidCredentialsException e) {
            return false;
        }
    }

    public List<User> searchUsers(String query) {
        String searchQuery = query.toLowerCase();
        return users.values().stream()
                .filter(user -> user.getUsername().toLowerCase().contains(searchQuery) ||
                        user.getName().toLowerCase().contains(searchQuery) ||
                        user.getEmail().toLowerCase().contains(searchQuery))
                .toList();
    }

    public void assignManagerToSector(UUID managerId, int sectorId) throws IOException {
        User user = users.get(managerId);
        if (user == null || !(user instanceof Manager)) {
            throw new IllegalArgumentException("Invalid manager ID");
        }

        Manager manager = (Manager) user;
        manager.addManagedSector(sectorId);
        saveUsers();
    }

    public void removeManagerFromSector(UUID managerId, int sectorId) throws IOException {
        User user = users.get(managerId);
        if (user == null || !(user instanceof Manager)) {
            throw new IllegalArgumentException("Invalid manager ID");
        }

        Manager manager = (Manager) user;
        manager.removeManagedSector(sectorId);
        saveUsers();
    }

    public Map<String, Object> getUserStats() {
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalUsers", users.size());
        stats.put("activeUsers", users.values().stream().filter(User::isActive).count());
        stats.put("cashiers", getUsersByRole(UserRole.CASHIER).size());
        stats.put("managers", getUsersByRole(UserRole.MANAGER).size());
        stats.put("administrators", getUsersByRole(UserRole.ADMINISTRATOR).size());

        return stats;
    }

    public void backup() throws IOException {
        dbUtil.backup(USER_FILE);
    }

    public void restore(String backupFile) throws IOException {
        dbUtil.restore(backupFile, USER_FILE);
        loadUsers(); // Reload users from the restored file
    }
}