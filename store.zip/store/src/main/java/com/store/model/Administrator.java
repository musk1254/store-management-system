package com.store.model;

import com.store.util.UserRole;

import java.time.LocalDateTime;
import java.util.*;

public class Administrator extends User {
    private Map<UUID, User> users;
    private Map<String, Double> revenueStats;

    public Administrator(String username, String password, String name, String email, String phone) {
        super(username, password, name, email, phone, UserRole.ADMINISTRATOR);
        this.users = new HashMap<>();
        this.revenueStats = new HashMap<>();
    }

    public void createUser(User user) throws IllegalArgumentException {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        if (users.containsKey(user.getId())) {
            throw new IllegalArgumentException("User already exists");
        }
        users.put(user.getId(), user);
    }

    public void modifyUser(UUID userId, User updatedUser) throws IllegalArgumentException {
        if (!users.containsKey(userId)) {
            throw new IllegalArgumentException("User not found");
        }
        users.put(userId, updatedUser);
    }

    public void deleteUser(UUID userId) throws IllegalArgumentException {
        if (!users.containsKey(userId)) {
            throw new IllegalArgumentException("User not found");
        }
        users.remove(userId);
    }

    public User getUser(UUID userId) {
        return users.get(userId);
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users.values());
    }

    public Map<String, Double> generateReports(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Double> report = new HashMap<>();
        calculateRevenue(startDate, endDate, report);
        calculateCosts(startDate, endDate, report);
        calculateProfit(report);
        return report;
    }

    private void calculateRevenue(LocalDateTime startDate, LocalDateTime endDate, Map<String, Double> report) {
        // Implementation for calculating revenue
    }

    private void calculateCosts(LocalDateTime startDate, LocalDateTime endDate, Map<String, Double> report) {
        // Implementation for calculating costs
    }

    private void calculateProfit(Map<String, Double> report) {
        double revenue = report.getOrDefault("revenue", 0.0);
        double costs = report.getOrDefault("costs", 0.0);
        report.put("profit", revenue - costs);
    }
}
