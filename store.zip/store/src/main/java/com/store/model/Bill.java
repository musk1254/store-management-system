package com.store.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Bill implements Serializable {
    private final String billNumber;
    private final Map<Item, Integer> items; // Item and quantity
    private double totalAmount;
    private final LocalDateTime saleDate;
    private final UUID cashierId;
    private boolean finalized;

    public Bill(UUID cashierId) {
        this.billNumber = generateBillNumber();
        this.items = new HashMap<>();
        this.totalAmount = 0.0;
        this.saleDate = LocalDateTime.now();
        this.cashierId = cashierId;
        this.finalized = false;
    }

    public void addItem(Item item, int quantity) throws IllegalArgumentException {
        if (finalized) {
            throw new IllegalArgumentException("Cannot modify a finalized bill");
        }
        if (!item.checkAvailability(quantity)) {
            throw new IllegalArgumentException("Item not available in requested quantity");
        }

        items.put(item, items.getOrDefault(item, 0) + quantity);
        updateTotal();
    }

    public void removeItem(Item item) throws IllegalArgumentException {
        if (finalized) {
            throw new IllegalArgumentException("Cannot modify a finalized bill");
        }
        if (items.remove(item) != null) {
            updateTotal();
        }
    }

    private void updateTotal() {
        this.totalAmount = items.entrySet().stream()
                .mapToDouble(entry -> entry.getKey().getSellingPrice() * entry.getValue())
                .sum();
    }

    public double calculateTotal() {
        return totalAmount;
    }

    public void finalizeBill() throws IllegalStateException {
        if (items.isEmpty()) {
            throw new IllegalStateException("Cannot finalize empty bill");
        }

        // Update stock for all items
        for (Map.Entry<Item, Integer> entry : items.entrySet()) {
            try {
                entry.getKey().updateStock(-entry.getValue());
            } catch (IllegalArgumentException e) {
                throw new IllegalStateException("Stock update failed: " + e.getMessage());
            }
        }

        this.finalized = true;
    }

    public String generatePrintableFormat() {
        StringBuilder bill = new StringBuilder();

        // Header
        bill.append("=================================\n");
        bill.append("           STORE RECEIPT         \n");
        bill.append("=================================\n");
        bill.append("Bill Number: ").append(billNumber).append("\n");
        bill.append("Date: ").append(saleDate.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n");
        bill.append("---------------------------------\n");

        // Items
        bill.append("Items:\n");
        items.forEach((item, quantity) -> {
            bill.append(String.format("%-20s x%d\n", item.getName(), quantity));
            bill.append(String.format("    Price: $%.2f    Total: $%.2f\n",
                    item.getSellingPrice(),
                    item.getSellingPrice() * quantity));
        });

        // Footer
        bill.append("---------------------------------\n");
        bill.append(String.format("Total Amount: $%.2f\n", totalAmount));
        bill.append("=================================\n");

        return bill.toString();
    }

    private String generateBillNumber() {
        return String.format("BILL-%s-%d",
                LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd")),
                System.nanoTime() % 10000);
    }

    // Getters and setters
    public String getBillNumber() { return billNumber; }

    public Map<Item, Integer> getItems() {
        return Collections.unmodifiableMap(items);
    }

    public LocalDateTime getSaleDate() { return saleDate; }

    public UUID getCashierId() { return cashierId; }

    public boolean isFinalized() { return finalized; }
}
