package com.store.model;

import com.store.util.UserRole;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Cashier extends User {
    private int sectorId;
    private List<Bill> dailyBills;

    public Cashier(String username, String password, String name, String email,
                   String phone, int sectorId) {
        super(username, password, name, email, phone, UserRole.CASHIER);
        this.sectorId = sectorId;
        this.dailyBills = new ArrayList<>();
    }

    public Bill createBill() {
        Bill newBill = new Bill(this.id);
        dailyBills.add(newBill);
        return newBill;
    }

    public List<Bill> viewDailyBills() {
        LocalDate today = LocalDate.now();
        return dailyBills.stream()
                .filter(bill -> bill.getSaleDate().toLocalDate().equals(today))
                .collect(Collectors.toList());
    }

    public double calculateDailyTotal() {
        return viewDailyBills().stream()
                .mapToDouble(Bill::calculateTotal)
                .sum();
    }

    public int getSectorId() { return sectorId; }

    public void clearDailyBills() {
        dailyBills.clear();
    }
}
