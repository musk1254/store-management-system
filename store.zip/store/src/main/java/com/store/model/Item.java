package com.store.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

public class Item implements Serializable {
    private final UUID id;
    private String name;
    private String category;
    private Supplier supplier;
    private LocalDateTime purchaseDate;
    private double purchasePrice;
    private double sellingPrice;
    private int quantity;
    private boolean active;

    public Item(String name, String category, Supplier supplier, double purchasePrice,
                double sellingPrice, int quantity) {
        this.id = UUID.randomUUID();
        this.name = name;
        this.category = category;
        this.supplier = supplier;
        this.purchaseDate = LocalDateTime.now();
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.quantity = quantity;
        this.active = true;
    }

    public synchronized void updateStock(int quantityChange) throws IllegalArgumentException {
        int newQuantity = this.quantity + quantityChange;
        if (newQuantity < 0) {
            throw new IllegalArgumentException("Insufficient stock");
        }
        this.quantity = newQuantity;
    }

    public boolean checkAvailability(int requestedQuantity) {
        return this.quantity >= requestedQuantity && this.active;
    }

    public double getProfit() {
        return sellingPrice - purchasePrice;
    }

    // Getters and setters with validation
    public UUID getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        }
    }

    public String getCategory() { return category; }
    public void setCategory(String category) {
        if (category != null && !category.trim().isEmpty()) {
            this.category = category;
        }
    }

    public Supplier getSupplier() { return supplier; }
    public void setSupplier(Supplier supplier) {
        if (supplier != null) {
            this.supplier = supplier;
        }
    }

    public LocalDateTime getPurchaseDate() { return purchaseDate; }

    public double getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(double purchasePrice) {
        if (purchasePrice >= 0) {
            this.purchasePrice = purchasePrice;
        }
    }

    public double getSellingPrice() { return sellingPrice; }
    public void setSellingPrice(double sellingPrice) {
        if (sellingPrice >= 0) {
            this.sellingPrice = sellingPrice;
        }
    }

    public int getQuantity() { return quantity; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
