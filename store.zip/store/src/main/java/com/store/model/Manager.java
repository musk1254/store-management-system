package com.store.model;

import com.store.util.UserRole;

import java.time.LocalDateTime;
import java.util.*;

public class Manager extends User {
    private List<Integer> managedSectors;
    private Map<UUID, Supplier> suppliers;
    private static final int LOW_STOCK_THRESHOLD = 5;

    public Manager(String username, String password, String name, String email, String phone) {
        super(username, password, name, email, phone, UserRole.MANAGER);
        this.managedSectors = new ArrayList<>();
        this.suppliers = new HashMap<>();
    }

    public void addItem(Item item) throws IllegalArgumentException {
        if (item == null) {
            throw new IllegalArgumentException("Item cannot be null");
        }
        // Additional logic for adding item to inventory
    }

    public void updateStock(Item item, int quantity) throws IllegalArgumentException {
        if (item == null) {
            throw new IllegalArgumentException("Item cannot be null");
        }
        item.updateStock(quantity);
        checkLowStock(item);
    }

    private void checkLowStock(Item item) {
        if (item.getQuantity() < LOW_STOCK_THRESHOLD) {
            // Notify manager about low stock
            System.out.println("Low stock alert for item: " + item.getName());
        }
    }

    public Map<String, Double> viewSalesStats(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Double> stats = new HashMap<>();
        // Implementation for calculating sales statistics
        return stats;
    }

    public void addSupplier(Supplier supplier) {
        suppliers.put(supplier.getId(), supplier);
    }

    public void removeSupplier(UUID supplierId) {
        suppliers.remove(supplierId);
    }

    public List<Supplier> getSuppliers() {
        return new ArrayList<>(suppliers.values());
    }

    public void addManagedSector(int sectorId) {
        if (!managedSectors.contains(sectorId)) {
            managedSectors.add(sectorId);
        }
    }

    public void removeManagedSector(int sectorId) {
        managedSectors.remove(Integer.valueOf(sectorId));
    }

    public List<Integer> getManagedSectors() {
        return new ArrayList<>(managedSectors);
    }
}
