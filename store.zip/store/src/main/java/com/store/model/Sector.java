package com.store.model;

import java.io.Serializable;
import java.util.*;

public class Sector implements Serializable {
    private int id;
    private String name;
    private String description;
    private boolean active;
    private List<UUID> assignedCashiers;
    private List<UUID> responsibleManagers;
    private Map<UUID, Item> sectorItems;

    public Sector(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.active = true;
        this.assignedCashiers = new ArrayList<>();
        this.responsibleManagers = new ArrayList<>();
        this.sectorItems = new HashMap<>();
    }

    // Cashier management
    public void assignCashier(UUID cashierId) {
        if (!assignedCashiers.contains(cashierId)) {
            assignedCashiers.add(cashierId);
        }
    }

    public void removeCashier(UUID cashierId) {
        assignedCashiers.remove(cashierId);
    }

    // Manager management
    public void assignManager(UUID managerId) {
        if (!responsibleManagers.contains(managerId)) {
            responsibleManagers.add(managerId);
        }
    }

    public void removeManager(UUID managerId) {
        responsibleManagers.remove(managerId);
    }

    // Item management
    public void addItem(Item item) {
        sectorItems.put(item.getId(), item);
    }

    public void removeItem(UUID itemId) {
        sectorItems.remove(itemId);
    }

    // Getters and setters
    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public List<UUID> getAssignedCashiers() { return new ArrayList<>(assignedCashiers); }
    public List<UUID> getResponsibleManagers() { return new ArrayList<>(responsibleManagers); }
    public Map<UUID, Item> getSectorItems() { return new HashMap<>(sectorItems); }

    // Utility methods
    public boolean hasCashier(UUID cashierId) {
        return assignedCashiers.contains(cashierId);
    }

    public boolean hasManager(UUID managerId) {
        return responsibleManagers.contains(managerId);
    }

    public boolean hasItem(UUID itemId) {
        return sectorItems.containsKey(itemId);
    }
}