package com.store.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;

public class Supplier implements Serializable {
    private final UUID id;
    private String name;
    private String contact;
    private String email;
    private String address;
    private List<String> productCategories;
    private Map<String, Double> pricing;
    private LocalDateTime lastOrderDate;
    private boolean active;

    public Supplier(String name, String contact, String email, String address) {
        this.id = UUID.randomUUID();
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.address = address;
        this.productCategories = new ArrayList<>();
        this.pricing = new HashMap<>();
        this.active = true;
    }

    public void addProduct(String category, double basePrice) throws IllegalArgumentException {
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("Category cannot be empty");
        }
        if (basePrice < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }

        productCategories.add(category);
        pricing.put(category, basePrice);
    }

    public void removeProduct(String category) {
        productCategories.remove(category);
        pricing.remove(category);
    }

    public void updatePricing(String category, double newPrice) throws IllegalArgumentException {
        if (!productCategories.contains(category)) {
            throw new IllegalArgumentException("Category not found");
        }
        if (newPrice < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }

        pricing.put(category, newPrice);
    }

    public void updateDetails(String name, String contact, String email, String address)
            throws IllegalArgumentException {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        }
        if (contact != null && !contact.trim().isEmpty()) {
            this.contact = contact;
        }
        if (email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            this.email = email;
        }
        if (address != null && !address.trim().isEmpty()) {
            this.address = address;
        }
    }

    public void recordOrder() {
        this.lastOrderDate = LocalDateTime.now();
    }

    // Getters and setters
    public UUID getId() { return id; }

    public String getName() { return name; }

    public String getContact() { return contact; }

    public String getEmail() { return email; }

    public String getAddress() { return address; }

    public List<String> getProductCategories() {
        return Collections.unmodifiableList(productCategories);
    }

    public Map<String, Double> getPricing() {
        return Collections.unmodifiableMap(pricing);
    }

    public LocalDateTime getLastOrderDate() { return lastOrderDate; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public Optional<Double> getPriceForCategory(String category) {
        return Optional.ofNullable(pricing.get(category));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Supplier supplier = (Supplier) o;
        return id.equals(supplier.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "name='" + name + '\'' +
                ", contact='" + contact + '\'' +
                ", categories=" + productCategories.size() +
                '}';
    }
}
