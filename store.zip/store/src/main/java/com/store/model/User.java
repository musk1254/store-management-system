package com.store.model;

import com.store.util.UserRole;
import com.store.util.InvalidCredentialsException;
import com.store.util.SessionManager;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public abstract class User implements Serializable {
    protected UUID id;
    protected String username;
    protected String password;
    protected String name;
    protected String email;
    protected String phone;
    protected LocalDateTime lastLogin;
    protected boolean active;
    protected UserRole role;

    public User(String username, String password, String name, String email, String phone, UserRole role) {
        this.id = UUID.randomUUID();
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.role = role;
        this.active = true;
        this.lastLogin = null;
    }

    public boolean login(String username, String password) throws InvalidCredentialsException {
        if (!this.active) {
            throw new InvalidCredentialsException("Account is deactivated");
        }
        if (this.username.equals(username) && this.password.equals(password)) {
            this.lastLogin = LocalDateTime.now();
            SessionManager.getInstance().startSession(this);
            return true;
        }
        throw new InvalidCredentialsException("Invalid username or password");
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        }
    }

    public void setEmail(String email) {
        if (email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            this.email = email;
        }
    }

    public void setPhone(String phone) {
        if (phone != null && phone.matches("^\\+?[0-9]{10,15}$")) {
            this.phone = phone;
        }
    }

    public UUID getId() { return id; }
    public String getUsername() { return username; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public LocalDateTime getLastLogin() { return lastLogin; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public UserRole getRole() { return role; }
    public String getPassword() { return password; }
    public void setPassword(String hashedPassword) { this.password = hashedPassword; }
}
