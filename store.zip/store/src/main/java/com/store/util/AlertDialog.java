package com.store.util;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.Node;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public class AlertDialog {
    private final Alert alert;
    private final DialogPane dialogPane;

    public AlertDialog(AlertType type, String title, String message) {
        alert = new Alert(convertAlertType(type));
        dialogPane = alert.getDialogPane();

        // Set basic properties
        alert.setTitle(title);
        alert.setHeaderText(null); // We'll use custom header styling

        // Create custom content
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        // Add icon based on type
        ImageView icon = createIcon(type);
        if (icon != null) {
            content.getChildren().add(icon);
        }

        // Add message with proper text wrapping
        TextFlow textFlow = new TextFlow();
        Text text = new Text(message);
        textFlow.getChildren().add(text);
        content.getChildren().add(textFlow);

        dialogPane.setContent(content);

        // Apply custom styling
        applyCustomStyling(type);

        // Make dialog modal
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initStyle(StageStyle.UNIFIED);
    }

    private ImageView createIcon(AlertType type) {
        String iconPath = switch (type) {
            case SUCCESS -> "/icons/success.png";
            case ERROR -> "/icons/error.png";
            case WARNING -> "/icons/warning.png";
            case INFO -> "/icons/info.png";
            case CONFIRM -> "/icons/confirm.png";
        };

        try {
            Image image = new Image(getClass().getResourceAsStream(iconPath));
            ImageView imageView = new ImageView(image);
            imageView.setFitHeight(32);
            imageView.setFitWidth(32);
            return imageView;
        } catch (Exception e) {
            return null;
        }
    }

    private void applyCustomStyling(AlertType type) {
        // Add custom styles based on type
        dialogPane.getStyleClass().add("custom-alert");
        dialogPane.getStyleClass().add(type.toString().toLowerCase() + "-alert");

        // Style all buttons in the dialog
        for (Node node : dialogPane.getButtonTypes().stream()
                .map(dialogPane::lookupButton)
                .toList()) {
            node.getStyleClass().add("alert-button");
        }
    }

    public void showAndWait() {
        alert.showAndWait();
    }

    public ButtonType show() {
        return alert.showAndWait().orElse(ButtonType.CANCEL);
    }

    // Add custom buttons
    public void addButton(ButtonType buttonType) {
        dialogPane.getButtonTypes().add(buttonType);
    }

    // Clear existing buttons and set new ones
    public void setButtons(ButtonType... buttonTypes) {
        dialogPane.getButtonTypes().clear();
        dialogPane.getButtonTypes().addAll(buttonTypes);
    }

    // Convert our custom AlertType to JavaFX AlertType
    private Alert.AlertType convertAlertType(AlertType type) {
        return switch (type) {
            case SUCCESS, INFO -> Alert.AlertType.INFORMATION;
            case WARNING -> Alert.AlertType.WARNING;
            case ERROR -> Alert.AlertType.ERROR;
            case CONFIRM -> Alert.AlertType.CONFIRMATION;
        };
    }

    // Custom alert type enum
    public enum AlertType {
        SUCCESS,
        ERROR,
        WARNING,
        INFO,
        CONFIRM
    }

    // Static convenience methods for common use cases
    public static void showSuccess(String message) {
        new AlertDialog(AlertType.SUCCESS, "Success", message).showAndWait();
    }

    public static void showError(String message) {
        new AlertDialog(AlertType.ERROR, "Error", message).showAndWait();
    }

    public static void showWarning(String message) {
        new AlertDialog(AlertType.WARNING, "Warning", message).showAndWait();
    }

    public static void showInfo(String message) {
        new AlertDialog(AlertType.INFO, "Information", message).showAndWait();
    }

    public static boolean showConfirm(String message) {
        AlertDialog dialog = new AlertDialog(AlertType.CONFIRM, "Confirm", message);
        return dialog.show() == ButtonType.OK;
    }
}