package com.store.util;

import com.store.model.User;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class AuthenticationService {
    private static AuthenticationService instance;
    private static final int MIN_PASSWORD_LENGTH = 8;

    private AuthenticationService() {
    }

    public static synchronized AuthenticationService getInstance() {
        if (instance == null) {
            instance = new AuthenticationService();
        }
        return instance;
    }

    public String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hash);
    }

    public void validatePassword(String password) throws InvalidCredentialsException {
        if (password == null || password.length() < MIN_PASSWORD_LENGTH) {
            throw new InvalidCredentialsException(
                    "Password must be at least " + MIN_PASSWORD_LENGTH + " characters long"
            );
        }

        if (!password.matches(".*[A-Z].*")) {
            throw new InvalidCredentialsException(
                    "Password must contain at least one uppercase letter"
            );
        }

        if (!password.matches(".*[a-z].*")) {
            throw new InvalidCredentialsException(
                    "Password must contain at least one lowercase letter"
            );
        }

        if (!password.matches(".*\\d.*")) {
            throw new InvalidCredentialsException(
                    "Password must contain at least one number"
            );
        }

        if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*")) {
            throw new InvalidCredentialsException(
                    "Password must contain at least one special character"
            );
        }
    }

    public void authenticate(User user, String username, String password)
            throws InvalidCredentialsException {
        try {
            if (!user.login(username, hashPassword(password))) {
                throw new InvalidCredentialsException("Invalid credentials", username);
            }
        } catch (NoSuchAlgorithmException e) {
            throw new InvalidCredentialsException("Authentication system error");
        }
    }
}