package com.store.util;

public class AuthorizationException extends Exception {
    private final UserRole requiredRole;
    private final String operation;

    public AuthorizationException(String message) {
        super(message);
        this.requiredRole = null;
        this.operation = null;
    }

    public AuthorizationException(String message, UserRole requiredRole, String operation) {
        super(message);
        this.requiredRole = requiredRole;
        this.operation = operation;
    }

    public UserRole getRequiredRole() {
        return requiredRole;
    }

    public String getOperation() {
        return operation;
    }
}