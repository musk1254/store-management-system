package com.store.util;

import java.util.Map;
import java.util.HashMap;
import java.io.*;
import com.store.model.*;

public class DatabaseUtil {
    private static DatabaseUtil instance;
    private static final String DB_PATH = "store_data/";
    private Map<String, String> dbConfig;

    private DatabaseUtil() {
        dbConfig = new HashMap<>();
        initializeDatabase();
    }

    public static synchronized DatabaseUtil getInstance() {
        if (instance == null) {
            instance = new DatabaseUtil();
        }
        return instance;
    }

    private void initializeDatabase() {
        File dbDir = new File(DB_PATH);
        if (!dbDir.exists()) {
            dbDir.mkdirs();
        }
        // Initialize database paths
        dbConfig.put("users", DB_PATH + "users.dat");
        dbConfig.put("items", DB_PATH + "items.dat");
        dbConfig.put("bills", DB_PATH + "bills.dat");
        dbConfig.put("suppliers", DB_PATH + "suppliers.dat");
        dbConfig.put("sectors", DB_PATH + "sectors.dat");
    }

    public String getPath(String entity) {
        return dbConfig.get(entity.toLowerCase());
    }

    public void backup(String sourceFile) throws IOException {
        String backupPath = DB_PATH + "backup/";
        File backupDir = new File(backupPath);
        if (!backupDir.exists()) {
            backupDir.mkdirs();
        }

        String timestamp = String.valueOf(System.currentTimeMillis());
        String backupFile = backupPath + new File(sourceFile).getName() + "." + timestamp;

        FileHandler.copyFile(sourceFile, backupFile);
    }

    public void restore(String backupFile, String targetFile) throws IOException {
        FileHandler.copyFile(backupFile, targetFile);
    }
}