package com.store.util;

import java.io.*;
import java.util.List;
import java.util.ArrayList;
import java.nio.file.*;

public class FileHandler {
    public static void writeObject(String filePath, Object obj) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(filePath))) {
            oos.writeObject(obj);
        }
    }

    public static Object readObject(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(filePath))) {
            return ois.readObject();
        }
    }

    public static void writeText(String filePath, String content) throws IOException {
        Files.write(Paths.get(filePath), content.getBytes());
    }

    public static String readText(String filePath) throws IOException {
        return new String(Files.readAllBytes(Paths.get(filePath)));
    }

    public static void appendText(String filePath, String content) throws IOException {
        Files.write(Paths.get(filePath), content.getBytes(),
                StandardOpenOption.APPEND, StandardOpenOption.CREATE);
    }

    public static void copyFile(String sourcePath, String targetPath) throws IOException {
        Files.copy(Paths.get(sourcePath), Paths.get(targetPath),
                StandardCopyOption.REPLACE_EXISTING);
    }

    public static void deleteFile(String filePath) throws IOException {
        Files.deleteIfExists(Paths.get(filePath));
    }

    public static List<String> listFiles(String directoryPath) throws IOException {
        List<String> fileList = new ArrayList<>();
        Files.walk(Paths.get(directoryPath))
                .filter(Files::isRegularFile)
                .forEach(path -> fileList.add(path.toString()));
        return fileList;
    }

    public static boolean exists(String filePath) {
        return Files.exists(Paths.get(filePath));
    }

    public static void createDirectory(String directoryPath) throws IOException {
        Files.createDirectories(Paths.get(directoryPath));
    }
}