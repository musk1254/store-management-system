package com.store.util;

public class InvalidCredentialsException extends Exception {
    private final String username;
    private final String reason;

    public InvalidCredentialsException(String message) {
        this(message, null, null);
    }

    public InvalidCredentialsException(String message, String username) {
        this(message, username, null);
    }

    public InvalidCredentialsException(String message, String username, String reason) {
        super(message);
        this.username = username;
        this.reason = reason;
    }

    public String getUsername() {
        return username;
    }

    public String getReason() {
        return reason;
    }
}
