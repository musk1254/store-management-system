package com.store.util;

import com.store.App;
import com.store.model.User;
import java.time.LocalDateTime;
import java.util.Optional;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private LocalDateTime sessionStartTime;
    private static final int SESSION_TIMEOUT_MINUTES = 30;

    private SessionManager() {
    }

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public synchronized void startSession(User user) throws InvalidCredentialsException {
        if (user == null) {
            throw new InvalidCredentialsException("User cannot be null");
        }
        this.currentUser = user;
        this.sessionStartTime = LocalDateTime.now();
    }

    public synchronized void endSession() {
        this.currentUser = null;
        this.sessionStartTime = null;
        App.showLoginScreen(); // Show login screen when session ends
    }

    public synchronized Optional<User> getCurrentUser() {
        if (isSessionValid()) {
            return Optional.ofNullable(currentUser);
        }
        endSession(); // This will now also show the login screen
        return Optional.empty();
    }

    public synchronized boolean isLoggedIn() {
        if (currentUser != null && isSessionValid()) {
            return true;
        }
        if (currentUser != null) {
            // Session has expired
            endSession(); // This will show the login screen
        }
        return false;
    }

    public synchronized void validateUserRole(UserRole requiredRole, String operation)
            throws AuthorizationException {
        if (!isLoggedIn()) {
            endSession(); // This will show the login screen
            throw new AuthorizationException("No active session found");
        }

        if (currentUser.getRole() != requiredRole) {
            throw new AuthorizationException(
                    "Insufficient privileges for this operation",
                    requiredRole,
                    operation
            );
        }
    }

    private boolean isSessionValid() {
        if (sessionStartTime == null) {
            return false;
        }

        LocalDateTime now = LocalDateTime.now();
        return sessionStartTime.plusMinutes(SESSION_TIMEOUT_MINUTES).isAfter(now);
    }

    public synchronized void refreshSession() throws InvalidCredentialsException {
        if (!isLoggedIn()) {
            endSession(); // This will show the login screen
            throw new InvalidCredentialsException("No active session to refresh");
        }
        this.sessionStartTime = LocalDateTime.now();
    }

    public synchronized Optional<LocalDateTime> getSessionStartTime() {
        return Optional.ofNullable(sessionStartTime);
    }

    public synchronized int getRemainingSessionTimeInMinutes() {
        if (!isLoggedIn() || sessionStartTime == null) {
            return 0;
        }

        LocalDateTime expiryTime = sessionStartTime.plusMinutes(SESSION_TIMEOUT_MINUTES);
        LocalDateTime now = LocalDateTime.now();

        long remainingMinutes = java.time.Duration.between(now, expiryTime).toMinutes();
        return (int) Math.max(0, remainingMinutes);
    }
}