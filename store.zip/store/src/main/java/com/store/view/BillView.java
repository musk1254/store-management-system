package com.store.view;

import com.store.controller.BillController;
import com.store.controller.ItemController;
import com.store.model.Bill;
import com.store.model.Item;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BillView {
    private final VBox mainContainer;
    private final HBox rootContainer;
    private final BillController billController;
    private TableView<BillItem> currentItemsTable;
    private final ObservableList<BillItem> currentItems;
    private Bill currentBill; // Add reference to current bill
    private final ItemController itemController;
    private final ComboBox<Item> itemComboBox;
    private final ObservableList<Item> availableItems;
    private Button finalizeBillButton;
    private Button printBillButton;
    private Label totalLabel;
    private double currentTotal = 0.0;

    public BillView() {
        this.billController = BillController.getInstance();
        this.itemController = ItemController.getInstance();
        this.currentItems = FXCollections.observableArrayList();
        this.availableItems = FXCollections.observableArrayList();
        this.itemComboBox = new ComboBox<>(availableItems);

        this.mainContainer = new VBox(20);
        this.rootContainer = new HBox(20);
        mainContainer.getStyleClass().add("dashboard-container");
        mainContainer.setPadding(new Insets(20));

        // Create components
        VBox topSection = createTopSection();
        VBox addItemSection = createAddItemSection();
        VBox currentItemsSection = createCurrentItemsSection();
        HBox actionButtonsSection = createActionButtonsSection();

        mainContainer.getChildren().addAll(
                topSection,
                addItemSection,
                actionButtonsSection
        );

        mainContainer.setPrefWidth(800);
        rootContainer.getChildren().addAll(mainContainer, currentItemsSection);

        loadAvailableItems();
    }

    private void loadAvailableItems() {
        List<Item> items = itemController.getActiveItems().stream()
                .filter(item -> item.getQuantity() > 0)
                .collect(Collectors.toList());
        availableItems.setAll(items);
    }

    private VBox createTopSection() {
        VBox topSection = new VBox(10);
        topSection.getStyleClass().add("dashboard-card");

        totalLabel = new Label("Total: $0.00");
        totalLabel.getStyleClass().add("total-label");

        topSection.getChildren().addAll(totalLabel);
        return topSection;
    }

    private VBox createAddItemSection() {
        VBox addItemSection = new VBox(10);
        addItemSection.getStyleClass().add("dashboard-card");
        addItemSection.setMinWidth(300);

        Text addItemTitle = new Text("Add Item");
        addItemTitle.getStyleClass().add("dashboard-subtitle");

        // Configure item ComboBox
        itemComboBox.setPromptText("Select Item");
        itemComboBox.setPrefWidth(300);
        setupItemComboBox();

        // Quantity spinner
        Spinner<Integer> quantitySpinner = new Spinner<>(1, 100, 1);
        quantitySpinner.setEditable(true);
        setupQuantitySpinner(quantitySpinner);

        // Search field
        TextField searchField = new TextField();
        searchField.setPromptText("Search items...");
        setupSearchField(searchField);

        Button addItemButton = new Button("Add to Bill");
        addItemButton.getStyleClass().add("button");
        addItemButton.setDisable(true);
        setupAddItemButton(addItemButton, quantitySpinner);

        addItemSection.getChildren().addAll(
                addItemTitle,
                searchField,
                itemComboBox,
                quantitySpinner,
                addItemButton
        );

        return addItemSection;
    }

    private void setupItemComboBox() {
        itemComboBox.setCellFactory(lv -> new ListCell<Item>() {
            @Override
            protected void updateItem(Item item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("%s - $%.2f (Stock: %d)",
                            item.getName(),
                            item.getSellingPrice(),
                            item.getQuantity()));
                }
            }
        });
        itemComboBox.setButtonCell(itemComboBox.getCellFactory().call(null));
    }

    private void setupQuantitySpinner(Spinner<Integer> spinner) {
        spinner.valueProperty().addListener((obs, oldValue, newValue) -> {
            Item selectedItem = itemComboBox.getValue();
            if (selectedItem != null && newValue > selectedItem.getQuantity()) {
                spinner.getValueFactory().setValue(selectedItem.getQuantity());
            }
        });

        itemComboBox.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                SpinnerValueFactory.IntegerSpinnerValueFactory factory =
                        (SpinnerValueFactory.IntegerSpinnerValueFactory) spinner.getValueFactory();
                factory.setMax(newValue.getQuantity());
                spinner.setValueFactory(factory);
            }
        });
    }

    private void setupSearchField(TextField searchField) {
        searchField.textProperty().addListener((obs, old, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                loadAvailableItems();
            } else {
                List<Item> filteredItems = itemController.searchItems(newValue).stream()
                        .filter(item -> item.isActive() && item.getQuantity() > 0)
                        .collect(Collectors.toList());
                availableItems.setAll(filteredItems);
            }
        });
    }

    private void setupAddItemButton(Button addItemButton, Spinner<Integer> quantitySpinner) {
        itemComboBox.valueProperty().addListener((obs, old, newValue) ->
                addItemButton.setDisable(newValue == null));

        addItemButton.setOnAction(e -> {
            Item selectedItem = itemComboBox.getValue();
            int quantity = quantitySpinner.getValue();

            if (selectedItem != null && quantity > 0) {
                addItemToCurrentBill(selectedItem, quantity);
                itemComboBox.setValue(null);
                quantitySpinner.getValueFactory().setValue(1);
                loadAvailableItems();
            }
        });
    }

    private VBox createCurrentItemsSection() {
        VBox currentItemsSection = new VBox(10);
        currentItemsSection.getStyleClass().add("dashboard-card");

        Text currentItemsTitle = new Text("Current Bill Items");
        currentItemsTitle.getStyleClass().add("dashboard-subtitle");

        currentItemsTable = createCurrentItemsTable();

        Button removeItemButton = new Button("Remove Selected Item");
        removeItemButton.getStyleClass().addAll("button", "warning");
        removeItemButton.setDisable(true);

        currentItemsTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, old, newValue) -> removeItemButton.setDisable(newValue == null));

        removeItemButton.setOnAction(e -> {
            BillItem selectedItem = currentItemsTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                currentItems.remove(selectedItem);
                updateTotal();
                loadAvailableItems();
            }
        });

        currentItemsSection.getChildren().addAll(
                currentItemsTitle,
                currentItemsTable,
                removeItemButton
        );

        return currentItemsSection;
    }

    private TableView<BillItem> createCurrentItemsTable() {
        TableView<BillItem> table = new TableView<>(currentItems);

        TableColumn<BillItem, String> nameCol = new TableColumn<>("Item");
        nameCol.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getItem().getName()));

        TableColumn<BillItem, String> quantityCol = new TableColumn<>("Quantity");
        quantityCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.valueOf(data.getValue().getQuantity())));

        TableColumn<BillItem, String> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("$%.2f",
                        data.getValue().getItem().getSellingPrice())));

        TableColumn<BillItem, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("$%.2f",
                        data.getValue().getTotal())));

        table.getColumns().addAll(nameCol, quantityCol, priceCol, totalCol);
        return table;
    }

    private HBox createActionButtonsSection() {
        HBox actionButtons = new HBox(10);
        actionButtons.getStyleClass().add("dashboard-card");

        finalizeBillButton = new Button("Create and Finalize Bill");
        finalizeBillButton.getStyleClass().addAll("button", "success");
        finalizeBillButton.setDisable(true);
        finalizeBillButton.setOnAction(e -> createAndFinalizeBill());

        printBillButton = new Button("Print Bill");
        printBillButton.getStyleClass().add("button");
        printBillButton.setDisable(true);
        printBillButton.setOnAction(e -> printCurrentBill());

        Button clearButton = new Button("Clear All");
        clearButton.getStyleClass().addAll("button", "warning");
        clearButton.setOnAction(e -> clearCurrentBill());

        actionButtons.getChildren().addAll(finalizeBillButton, printBillButton, clearButton);
        return actionButtons;
    }

    private void addItemToCurrentBill(Item item, int quantity) {
        BillItem newItem = new BillItem(item, quantity);
        currentItems.add(newItem);
        updateTotal();
        finalizeBillButton.setDisable(currentItems.isEmpty());
    }

    private void updateTotal() {
        currentTotal = currentItems.stream()
                .mapToDouble(BillItem::getTotal)
                .sum();
        totalLabel.setText(String.format("Total: $%.2f", currentTotal));
        finalizeBillButton.setDisable(currentItems.isEmpty());
    }

    private void createAndFinalizeBill() {
        try {
            Bill bill = billController.createBill();

            // Add all items to the bill
            for (BillItem billItem : currentItems) {
                billController.addItemToBill(
                        bill.getBillNumber(),
                        billItem.getItem(),
                        billItem.getQuantity()
                );
            }

            billController.finalizeBill(bill.getBillNumber());
            printBillButton.setDisable(false);
            finalizeBillButton.setDisable(true);

            showSuccessMessage("Bill created and finalized successfully!");
        } catch (Exception e) {
            showErrorMessage("Error creating bill: " + e.getMessage());
        }
    }

    private void printCurrentBill() {
        if (currentBill == null) {
            showErrorMessage("No bill selected");
            return;
        }

        try {
            String printableContent = billController.printBill(currentBill.getBillNumber());
            showPrintPreview(printableContent);
        } catch (Exception e) {
            showErrorMessage("Failed to print bill: " + e.getMessage());
        }
    }

    private void showPrintPreview(String content) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Print Preview");
        dialog.setHeaderText(null);

        TextArea textArea = new TextArea(content);
        textArea.setEditable(false);
        textArea.setPrefRowCount(20);
        textArea.setPrefColumnCount(50);

        dialog.getDialogPane().setContent(textArea);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    private void clearCurrentBill() {
        currentItems.clear();
        updateTotal();
        finalizeBillButton.setDisable(true);
        printBillButton.setDisable(true);
        currentBill = null; // Clear the current bill reference
        loadAvailableItems();
    }

    private void showSuccessMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public HBox getView() {
        return rootContainer;
    }

    // Helper class for bill items table
    private static class BillItem {
        private final Item item;
        private final int quantity;

        public BillItem(Item item, int quantity) {
            this.item = item;
            this.quantity = quantity;
        }

        public Item getItem() { return item; }
        public int getQuantity() { return quantity; }
        public double getTotal() { return item.getSellingPrice() * quantity; }
    }
}