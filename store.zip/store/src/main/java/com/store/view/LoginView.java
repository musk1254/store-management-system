package com.store.view;

import com.store.App;
import com.store.controller.UserController;
import com.store.util.ValidationUtil;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class LoginView {
    private final StackPane rootPane;
    private final VBox view;
    private final TextField usernameField;
    private final PasswordField passwordField;
    private final Button loginButton;
    private final Button registerButton;
    private final Text errorText;

    public LoginView() {
        // Root pane to center the content
        rootPane = new StackPane();
        rootPane.getStyleClass().add("root-pane");

        // Main content container
        view = new VBox(20);
        view.getStyleClass().add("login-container");
        view.setAlignment(Pos.CENTER);
        view.setMaxWidth(400); // Limit the width of the form
        view.setPadding(new Insets(40));

        // Title
        Text title = new Text("Electronics Store Management System");
        title.getStyleClass().add("login-title");

        // Username field
        usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.getStyleClass().add("login-field");

        // Password field
        passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("login-field");

        // Buttons container
        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.CENTER);

        // Login button
        loginButton = new Button("Login");
        loginButton.getStyleClass().addAll("button", "login-button");

        // Register button
        registerButton = new Button("Register");
        registerButton.getStyleClass().addAll("button", "secondary", "register-button");

        buttonsBox.getChildren().addAll(loginButton, registerButton);

        // Error text
        errorText = new Text();
        errorText.getStyleClass().add("error-text");
        errorText.setVisible(false);

        // Form container
        VBox formBox = new VBox(15);
        formBox.setAlignment(Pos.CENTER);
        formBox.getStyleClass().add("login-form");
        formBox.getChildren().addAll(
                title,
                usernameField,
                passwordField,
                buttonsBox,
                errorText
        );

        // Add form to main container
        view.getChildren().add(formBox);

        // Center the view in the root pane
        rootPane.getChildren().add(view);

        setupEventHandlers();
    }

    private void setupEventHandlers() {
        loginButton.setOnAction(e -> handleLogin());
        registerButton.setOnAction(e -> showRegisterView());
        passwordField.setOnAction(e -> handleLogin());

        // Clear error on input
        usernameField.textProperty().addListener((obs, old, newValue) -> errorText.setVisible(false));
        passwordField.textProperty().addListener((obs, old, newValue) -> errorText.setVisible(false));
    }

    private void showRegisterView() {
        RegisterView registerView = new RegisterView();
        Scene scene = new Scene(registerView.getView());
        scene.getStylesheets().add("/styles/style.css");
        App.getPrimaryStage().setScene(scene);
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password");
            return;
        }

        if (!ValidationUtil.isValidUsername(username)) {
            showError("Invalid username format");
            return;
        }

        loginButton.setDisable(true);

        new Thread(() -> {
            boolean success = UserController.getInstance().authenticateUser(username, password);

            Platform.runLater(() -> {
                if (success) {
                    clearFields();
                    App.showDashboard();
                } else {
                    showError("Invalid username or password");
                    loginButton.setDisable(false);
                }
            });
        }).start();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisible(true);
    }

    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        errorText.setVisible(false);
    }

    public StackPane getView() {
        return rootPane;
    }
}