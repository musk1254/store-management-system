package com.store.view;

import com.store.controller.InventoryController;
import com.store.controller.ItemController;
import com.store.controller.SupplierController;
import com.store.model.Item;
import com.store.model.Supplier;
import com.store.util.AlertDialog;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.util.Optional;

public class ManageInventory {
    private final VBox rootPane;
    private final ItemController itemController;
    private final SupplierController supplierController;
    private final TableView<Item> itemTable;
    private final ObservableList<Item> itemList;

    public ManageInventory() {
        this.itemController = ItemController.getInstance();
        this.supplierController = SupplierController.getInstance();
        this.itemList = FXCollections.observableArrayList();

        rootPane = new VBox(10);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);

        // Create controls
        HBox controlBox = new HBox(10);
        controlBox.setAlignment(Pos.CENTER);

        TextField searchField = new TextField();
        searchField.setPromptText("Search items...");
        searchField.setPrefWidth(300);

        Button addButton = new Button("Add Item");
        addButton.getStyleClass().add("button-primary");
        addButton.setOnAction(e -> showAddEditDialog(null));

        Button refreshButton = new Button("Refresh");
        refreshButton.setOnAction(e -> refreshItems());

        controlBox.getChildren().addAll(searchField, addButton, refreshButton);

        // Create table
        itemTable = createTable();

        // Add search functionality
        searchField.textProperty().addListener((obs, oldText, newText) ->
                itemList.setAll(itemController.searchItems(newText))
        );

        rootPane.getChildren().addAll(controlBox, itemTable);
        refreshItems();
    }

    private TableView<Item> createTable() {
        TableView<Item> table = new TableView<>(itemList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Item, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));

        TableColumn<Item, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getCategory()));

        TableColumn<Item, String> supplierCol = new TableColumn<>("Supplier");
        supplierCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getSupplier().getName()));

        TableColumn<Item, Number> quantityCol = new TableColumn<>("Stock");
        quantityCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleIntegerProperty(data.getValue().getQuantity()));

        TableColumn<Item, Number> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleDoubleProperty(data.getValue().getSellingPrice()));

        TableColumn<Item, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setCellFactory(col -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button stockButton = new Button("Stock");
            private final Button deleteButton = new Button("Delete");
            private final HBox actions = new HBox(5, editButton, stockButton, deleteButton);

            {
                editButton.getStyleClass().add("button-small");
                stockButton.getStyleClass().add("button-small");
                deleteButton.getStyleClass().add("button-small");

                editButton.setOnAction(e -> {
                    Item item = getTableRow().getItem();
                    if (item != null) showAddEditDialog(item);
                });

                stockButton.setOnAction(e -> {
                    Item item = getTableRow().getItem();
                    if (item != null) showStockDialog(item);
                });

                deleteButton.setOnAction(e -> {
                    Item item = getTableRow().getItem();
                    if (item != null) handleDelete(item);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : actions);
            }
        });

        table.getColumns().addAll(nameCol, categoryCol, supplierCol, quantityCol, priceCol, actionsCol);
        return table;
    }

    private void showAddEditDialog(Item item) {
        Dialog<Item> dialog = new Dialog<>();
        dialog.setTitle(item == null ? "Add New Item" : "Edit Item");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField();
        TextField categoryField = new TextField();
        ComboBox<Supplier> supplierBox = new ComboBox<>();
        TextField purchasePriceField = new TextField();
        TextField sellingPriceField = new TextField();
        TextField quantityField = new TextField();

        supplierBox.setItems(FXCollections.observableArrayList(supplierController.getActiveSuppliers()));

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Category:"), 0, 1);
        grid.add(categoryField, 1, 1);
        grid.add(new Label("Supplier:"), 0, 2);
        grid.add(supplierBox, 1, 2);
        grid.add(new Label("Purchase Price:"), 0, 3);
        grid.add(purchasePriceField, 1, 3);
        grid.add(new Label("Selling Price:"), 0, 4);
        grid.add(sellingPriceField, 1, 4);

        if (item == null) {
            grid.add(new Label("Initial Stock:"), 0, 5);
            grid.add(quantityField, 1, 5);
        }

        if (item != null) {
            nameField.setText(item.getName());
            categoryField.setText(item.getCategory());
            supplierBox.setValue(item.getSupplier());
            purchasePriceField.setText(String.valueOf(item.getPurchasePrice()));
            sellingPriceField.setText(String.valueOf(item.getSellingPrice()));
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    if (item == null) {
                        return itemController.createItem(
                                nameField.getText(),
                                categoryField.getText(),
                                supplierBox.getValue().getId(),
                                Double.parseDouble(purchasePriceField.getText()),
                                Double.parseDouble(sellingPriceField.getText()),
                                Integer.parseInt(quantityField.getText())
                        );
                    } else {
                        itemController.updateItem(
                                item.getId(),
                                nameField.getText(),
                                categoryField.getText(),
                                supplierBox.getValue().getId(),
                                Double.parseDouble(purchasePriceField.getText()),
                                Double.parseDouble(sellingPriceField.getText())
                        );
                        return item;
                    }
                } catch (Exception e) {
                    AlertDialog.showError(e.getMessage());
                    return null;
                }
            }
            return null;
        });

        Optional<Item> result = dialog.showAndWait();
        result.ifPresent(i -> refreshItems());
    }

    private void showStockDialog(Item item) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Update Stock");

        ButtonType updateButtonType = new ButtonType("Update", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(updateButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField quantityField = new TextField();
        grid.add(new Label("Quantity Change (+/-):"), 0, 0);
        grid.add(quantityField, 1, 0);

        dialog.getDialogPane().setContent(grid);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == updateButtonType) {
            try {
                int change = Integer.parseInt(quantityField.getText());
                itemController.updateStock(item.getId(), change);
                refreshItems();
                AlertDialog.showSuccess("Stock updated successfully");
            } catch (Exception e) {
                AlertDialog.showError(e.getMessage());
            }
        }
    }

    private void handleDelete(Item item) {
        if (AlertDialog.showConfirm("Are you sure you want to delete this item?")) {
            try {
                itemController.deactivateItem(item.getId());
                refreshItems();
                AlertDialog.showSuccess("Item deleted successfully");
            } catch (IOException e) {
                AlertDialog.showError("Error deleting item: " + e.getMessage());
            }
        }
    }

    private void refreshItems() {
        itemList.setAll(itemController.getAllItems());
    }

    public VBox getView() {
        return rootPane;
    }
}