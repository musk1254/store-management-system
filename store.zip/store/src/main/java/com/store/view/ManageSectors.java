package com.store.view;

import com.store.controller.SectorController;
import com.store.model.Sector;
import com.store.util.AlertDialog;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.util.Optional;

public class ManageSectors {
    private final VBox rootPane;
    private final SectorController sectorController;
    private final TableView<Sector> sectorTable;
    private final ObservableList<Sector> sectorList;

    public ManageSectors() {
        this.sectorController = SectorController.getInstance();
        this.sectorList = FXCollections.observableArrayList();

        rootPane = new VBox(10);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);

        // Create controls
        HBox controlBox = new HBox(10);
        controlBox.setAlignment(Pos.CENTER);

        Button addButton = new Button("Add Sector");
        addButton.getStyleClass().add("button-primary");
        addButton.setOnAction(e -> showAddEditDialog(null));

        Button refreshButton = new Button("Refresh");
        refreshButton.setOnAction(e -> refreshSectors());

        controlBox.getChildren().addAll(addButton, refreshButton);

        // Create table
        sectorTable = createTable();

        rootPane.getChildren().addAll(controlBox, sectorTable);
        refreshSectors();
    }

    private TableView<Sector> createTable() {
        TableView<Sector> table = new TableView<>(sectorList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Sector, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(data.getValue().getId())));

        TableColumn<Sector, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));

        TableColumn<Sector, String> descriptionCol = new TableColumn<>("Description");
        descriptionCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getDescription()));

        TableColumn<Sector, String> cashiersCol = new TableColumn<>("Cashiers");
        cashiersCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(data.getValue().getAssignedCashiers().size())));

        TableColumn<Sector, String> managersCol = new TableColumn<>("Managers");
        managersCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(data.getValue().getResponsibleManagers().size())));

        TableColumn<Sector, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        data.getValue().isActive() ? "Active" : "Inactive"));

        TableColumn<Sector, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setCellFactory(col -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button toggleButton = new Button("Toggle");
            private final HBox actions = new HBox(5, editButton, toggleButton);

            {
                editButton.getStyleClass().add("button-small");
                toggleButton.getStyleClass().add("button-small");

                editButton.setOnAction(e -> {
                    Sector sector = getTableRow().getItem();
                    if (sector != null) showAddEditDialog(sector);
                });

                toggleButton.setOnAction(e -> {
                    Sector sector = getTableRow().getItem();
                    if (sector != null) handleToggleActive(sector);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : actions);
            }
        });

        table.getColumns().addAll(idCol, nameCol, descriptionCol,
                cashiersCol, managersCol, statusCol, actionsCol);
        return table;
    }

    private void showAddEditDialog(Sector sector) {
        Dialog<Sector> dialog = new Dialog<>();
        dialog.setTitle(sector == null ? "Add New Sector" : "Edit Sector");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField();
        TextField descriptionField = new TextField();

        if (sector != null) {
            nameField.setText(sector.getName());
            descriptionField.setText(sector.getDescription());
        }

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    if (sector == null) {
                        return sectorController.createSector(
                                nameField.getText(),
                                descriptionField.getText()
                        );
                    } else {
                        sectorController.updateSector(
                                sector.getId(),
                                nameField.getText(),
                                descriptionField.getText()
                        );
                        return sector;
                    }
                } catch (Exception e) {
                    AlertDialog.showError(e.getMessage());
                    return null;
                }
            }
            return null;
        });

        Optional<Sector> result = dialog.showAndWait();
        result.ifPresent(s -> refreshSectors());
    }

    private void handleToggleActive(Sector sector) {
        try {
            if (sector.isActive()) {
                sectorController.deactivateSector(sector.getId());
            } else {
                sectorController.activateSector(sector.getId());
            }
            refreshSectors();
            AlertDialog.showSuccess("Sector status updated successfully");
        } catch (IOException e) {
            AlertDialog.showError("Error updating sector status: " + e.getMessage());
        }
    }

    private void refreshSectors() {
        sectorList.setAll(sectorController.getAllSectors());
    }

    public VBox getView() {
        return rootPane;
    }
}