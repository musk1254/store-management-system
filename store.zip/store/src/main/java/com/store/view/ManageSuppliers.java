package com.store.view;

import com.store.controller.SupplierController;
import com.store.model.Supplier;
import com.store.util.AlertDialog;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Optional;

public class ManageSuppliers {
    private final StackPane rootPane;
    private final VBox contentBox;
    private final TableView<Supplier> supplierTable;
    private final SupplierController supplierController;
    private final ObservableList<Supplier> supplierList;
    private final TextField searchField;

    public ManageSuppliers() {
        this.supplierController = SupplierController.getInstance();
        this.rootPane = new StackPane();
        this.contentBox = new VBox(20);
        this.supplierList = FXCollections.observableArrayList();

        // Setup the main container
        contentBox.setPadding(new Insets(20));
        contentBox.setAlignment(Pos.TOP_CENTER);
        contentBox.getStyleClass().add("content-container");

        // Add title
        Text title = new Text("Manage Suppliers");
        title.getStyleClass().add("page-title");

        // Create search and action buttons
        HBox actionBox = createActionBox();

        // Create supplier table
        this.supplierTable = createSupplierTable();
        this.searchField = new TextField();
        setupSearch();

        // Add everything to the content box
        contentBox.getChildren().addAll(title, actionBox, searchField, supplierTable);

        // Add content to root
        rootPane.getChildren().add(contentBox);

        // Load initial data
        refreshSupplierList();
    }

    private HBox createActionBox() {
        HBox actionBox = new HBox(10);
        actionBox.setAlignment(Pos.CENTER_RIGHT);

        Button addButton = new Button("Add New Supplier");
        addButton.getStyleClass().addAll("button", "primary");
        addButton.setOnAction(e -> showSupplierDialog(null));

        Button refreshButton = new Button("Refresh");
        refreshButton.getStyleClass().addAll("button", "secondary");
        refreshButton.setOnAction(e -> refreshSupplierList());

        actionBox.getChildren().addAll(addButton, refreshButton);
        return actionBox;
    }

    private TableView<Supplier> createSupplierTable() {
        TableView<Supplier> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Create columns
        TableColumn<Supplier, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(
                data.getValue().getName()));

        TableColumn<Supplier, String> contactCol = new TableColumn<>("Contact");
        contactCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(
                data.getValue().getContact()));

        TableColumn<Supplier, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(
                data.getValue().getEmail()));

        TableColumn<Supplier, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(
                data.getValue().isActive() ? "Active" : "Inactive"));

        TableColumn<Supplier, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setCellFactory(col -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");
            private final Button toggleButton = new Button("Toggle");
            private final HBox buttonBox = new HBox(5, editButton, deleteButton, toggleButton);

            {
                editButton.getStyleClass().addAll("button", "small", "primary");
                deleteButton.getStyleClass().addAll("button", "small", "danger");
                toggleButton.getStyleClass().addAll("button", "small", "warning");

                editButton.setOnAction(e -> {
                    Supplier supplier = getTableRow().getItem();
                    if (supplier != null) {
                        showSupplierDialog(supplier);
                    }
                });

                deleteButton.setOnAction(e -> {
                    Supplier supplier = getTableRow().getItem();
                    if (supplier != null) {
                        handleDelete(supplier);
                    }
                });

                toggleButton.setOnAction(e -> {
                    Supplier supplier = getTableRow().getItem();
                    if (supplier != null) {
                        handleToggleActive(supplier);
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : buttonBox);
            }
        });

        table.getColumns().addAll(nameCol, contactCol, emailCol, statusCol, actionsCol);
        table.setItems(supplierList);

        return table;
    }

    private void setupSearch() {
        searchField.setPromptText("Search suppliers...");
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                supplierList.setAll(supplierController.getAllSuppliers());
            } else {
                supplierList.setAll(supplierController.searchSuppliers(newValue));
            }
        });
    }

    private void showSupplierDialog(Supplier supplier) {
        Dialog<Supplier> dialog = new Dialog<>();
        dialog.setTitle(supplier == null ? "Add New Supplier" : "Edit Supplier");

        // Set the button types
        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // Create the form grid
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField();
        TextField contactField = new TextField();
        TextField emailField = new TextField();
        TextField addressField = new TextField();

        if (supplier != null) {
            nameField.setText(supplier.getName());
            contactField.setText(supplier.getContact());
            emailField.setText(supplier.getEmail());
            addressField.setText(supplier.getAddress());
        }

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Contact:"), 0, 1);
        grid.add(contactField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(new Label("Address:"), 0, 3);
        grid.add(addressField, 1, 3);

        dialog.getDialogPane().setContent(grid);

        // Convert the result to supplier object when button is clicked
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    if (supplier == null) {
                        return supplierController.createSupplier(
                                nameField.getText(),
                                contactField.getText(),
                                emailField.getText(),
                                addressField.getText()
                        );
                    } else {
                        supplierController.updateSupplier(
                                supplier.getId(),
                                nameField.getText(),
                                contactField.getText(),
                                emailField.getText(),
                                addressField.getText()
                        );
                        return supplier;
                    }
                } catch (IllegalArgumentException | IOException e) {
                    AlertDialog.showError(e.getMessage());
                    return null;
                }
            }
            return null;
        });

        Optional<Supplier> result = dialog.showAndWait();
        result.ifPresent(s -> refreshSupplierList());
    }

    private void handleDelete(Supplier supplier) {
        if (AlertDialog.showConfirm("Are you sure you want to delete this supplier?")) {
            try {
                // Instead of actual deletion, we'll deactivate the supplier
                supplierController.deactivateSupplier(supplier.getId());
                refreshSupplierList();
                AlertDialog.showSuccess("Supplier successfully deactivated");
            } catch (IOException e) {
                AlertDialog.showError("Error deactivating supplier: " + e.getMessage());
            }
        }
    }

    private void handleToggleActive(Supplier supplier) {
        try {
            if (supplier.isActive()) {
                supplierController.deactivateSupplier(supplier.getId());
            } else {
                supplierController.activateSupplier(supplier.getId());
            }
            refreshSupplierList();
            AlertDialog.showSuccess("Supplier status updated successfully");
        } catch (IOException e) {
            AlertDialog.showError("Error updating supplier status: " + e.getMessage());
        }
    }

    private void refreshSupplierList() {
        supplierList.setAll(supplierController.getAllSuppliers());
    }

    public StackPane getView() {
        return rootPane;
    }
}