package com.store.view;

import com.store.controller.UserController;
import com.store.controller.SectorController;
import com.store.model.User;
import com.store.util.AlertDialog;
import com.store.util.UserRole;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.util.Optional;

public class ManageUsers {
    private final VBox rootPane;
    private final UserController userController;
    private final SectorController sectorController;
    private final TableView<User> userTable;
    private final ObservableList<User> userList;

    public ManageUsers() {
        this.userController = UserController.getInstance();
        this.sectorController = SectorController.getInstance();
        this.userList = FXCollections.observableArrayList();

        rootPane = new VBox(10);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);

        // Create controls
        HBox controlBox = new HBox(10);
        controlBox.setAlignment(Pos.CENTER);

        TextField searchField = new TextField();
        searchField.setPromptText("Search users...");
        searchField.setPrefWidth(300);

        Button addButton = new Button("Add User");
        addButton.getStyleClass().add("button-primary");
        addButton.setOnAction(e -> showAddEditDialog(null));

        Button refreshButton = new Button("Refresh");
        refreshButton.setOnAction(e -> refreshUsers());

        controlBox.getChildren().addAll(searchField, addButton, refreshButton);

        // Create table
        userTable = createTable();

        // Add search functionality
        searchField.textProperty().addListener((obs, oldText, newText) ->
                userList.setAll(userController.searchUsers(newText))
        );

        rootPane.getChildren().addAll(controlBox, userTable);
        refreshUsers();
    }

    private TableView<User> createTable() {
        TableView<User> table = new TableView<>(userList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        usernameCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getUsername()));

        TableColumn<User, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));

        TableColumn<User, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getEmail()));

        TableColumn<User, String> roleCol = new TableColumn<>("Role");
        roleCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getRole().toString()));

        TableColumn<User, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        data.getValue().isActive() ? "Active" : "Inactive"));

        TableColumn<User, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setCellFactory(col -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button passwordButton = new Button("Password");
            private final Button toggleButton = new Button("Toggle");
            private final HBox actions = new HBox(5, editButton, passwordButton, toggleButton);

            {
                editButton.getStyleClass().add("button-small");
                passwordButton.getStyleClass().add("button-small");
                toggleButton.getStyleClass().add("button-small");

                editButton.setOnAction(e -> {
                    User user = getTableRow().getItem();
                    if (user != null) showAddEditDialog(user);
                });

                passwordButton.setOnAction(e -> {
                    User user = getTableRow().getItem();
                    if (user != null) showPasswordDialog(user);
                });

                toggleButton.setOnAction(e -> {
                    User user = getTableRow().getItem();
                    if (user != null) handleToggleActive(user);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : actions);
            }
        });

        table.getColumns().addAll(usernameCol, nameCol, emailCol, roleCol, statusCol, actionsCol);
        return table;
    }

    private void showAddEditDialog(User user) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle(user == null ? "Add New User" : "Edit User");
        //height
        dialog.setHeight(500);
        //width
        dialog.setWidth(500);

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField nameField = new TextField();
        TextField emailField = new TextField();
        TextField phoneField = new TextField();
        ComboBox<UserRole> roleBox = new ComboBox<>();
        ComboBox<Integer> sectorBox = new ComboBox<>();

        roleBox.setItems(FXCollections.observableArrayList(UserRole.values()));
        sectorBox.setItems(FXCollections.observableArrayList(
                sectorController.getAllSectors().stream()
                        .map(sector -> sector.getId())
                        .toList()
        ));

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);

        if (user == null) {
            grid.add(new Label("Password:"), 0, 1);
            grid.add(passwordField, 1, 1);
        }

        grid.add(new Label("Name:"), 0, 2);
        grid.add(nameField, 1, 2);
        grid.add(new Label("Email:"), 0, 3);
        grid.add(emailField, 1, 3);
        grid.add(new Label("Phone:"), 0, 4);
        grid.add(phoneField, 1, 4);
        grid.add(new Label("Role:"), 0, 5);
        grid.add(roleBox, 1, 5);

        // Show sector box only for Cashier role
        roleBox.setOnAction(e -> {
            if (roleBox.getValue() == UserRole.CASHIER) {
                grid.add(new Label("Sector:"), 0, 6);
                grid.add(sectorBox, 1, 6);
            } else {
                grid.getChildren().removeIf(node ->
                        GridPane.getRowIndex(node) != null && GridPane.getRowIndex(node) == 6);
            }
        });

        if (user != null) {
            usernameField.setText(user.getUsername());
            usernameField.setDisable(true);
            nameField.setText(user.getName());
            emailField.setText(user.getEmail());
            phoneField.setText(user.getPhone());
            roleBox.setValue(user.getRole());
            roleBox.setDisable(true);
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    if (user == null) {
                        return userController.createUser(
                                usernameField.getText(),
                                passwordField.getText(),
                                nameField.getText(),
                                emailField.getText(),
                                phoneField.getText(),
                                roleBox.getValue(),
                                roleBox.getValue() == UserRole.CASHIER ? sectorBox.getValue() : null
                        );
                    } else {
                        userController.updateUser(
                                user.getId(),
                                nameField.getText(),
                                emailField.getText(),
                                phoneField.getText()
                        );
                        return user;
                    }
                } catch (Exception e) {
                    AlertDialog.showError(e.getMessage());
                    return null;
                }
            }
            return null;
        });

        Optional<User> result = dialog.showAndWait();
        result.ifPresent(u -> refreshUsers());
    }

    private void showPasswordDialog(User user) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Change Password");

        ButtonType updateButtonType = new ButtonType("Update", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(updateButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        PasswordField oldPasswordField = new PasswordField();
        PasswordField newPasswordField = new PasswordField();
        PasswordField confirmPasswordField = new PasswordField();

        grid.add(new Label("Current Password:"), 0, 0);
        grid.add(oldPasswordField, 1, 0);
        grid.add(new Label("New Password:"), 0, 1);
        grid.add(newPasswordField, 1, 1);
        grid.add(new Label("Confirm Password:"), 0, 2);
        grid.add(confirmPasswordField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == updateButtonType) {
            if (!newPasswordField.getText().equals(confirmPasswordField.getText())) {
                AlertDialog.showError("Passwords do not match!");
                return;
            }
            try {
                userController.changeUserPassword(user.getId(),
                        oldPasswordField.getText(), newPasswordField.getText());
                AlertDialog.showSuccess("Password updated successfully");
            } catch (Exception e) {
                AlertDialog.showError(e.getMessage());
            }
        }
    }

    private void handleToggleActive(User user) {
        try {
            if (user.isActive()) {
                userController.deactivateUser(user.getId());
            } else {
                userController.activateUser(user.getId());
            }
            refreshUsers();
            AlertDialog.showSuccess("User status updated successfully");
        } catch (IOException e) {
            AlertDialog.showError("Error updating user status: " + e.getMessage());
        }
    }

    private void refreshUsers() {
        userList.setAll(userController.getAllUsers());
    }

    public VBox getView() {
        return rootPane;
    }
}