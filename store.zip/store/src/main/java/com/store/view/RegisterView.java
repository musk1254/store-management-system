package com.store.view;

import com.store.App;
import com.store.controller.UserController;
import com.store.controller.SectorController;
import com.store.model.Sector;
import com.store.model.User;
import com.store.util.AlertDialog;
import com.store.util.UserRole;
import com.store.util.ValidationUtil;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import java.io.IOException;
import java.util.Optional;

public class RegisterView {
    private final StackPane rootPane;
    private final VBox view;
    private final TextField usernameField;
    private final PasswordField passwordField;
    private final PasswordField confirmPasswordField;
    private final TextField nameField;
    private final TextField emailField;
    private final TextField phoneField;
    private final ComboBox<UserRole> roleComboBox;
    private final ComboBox<Sector> sectorComboBox;
    private final Button registerButton;
    private final Button backToLoginButton;
    private final Button createSectorButton;
    private final Text errorText;
    private final UserController userController;
    private final SectorController sectorController;

    public RegisterView() {
        this.userController = UserController.getInstance();
        this.sectorController = SectorController.getInstance();

        // Root pane setup
        rootPane = new StackPane();
        rootPane.getStyleClass().add("root-pane");

        // Main container
        view = new VBox(20);
        view.getStyleClass().add("register-container");
        view.setAlignment(Pos.CENTER);
        view.setMaxWidth(400);
        view.setPadding(new Insets(40));

        // Initialize components
        Text title = new Text("Register New User");
        title.getStyleClass().add("register-title");

        usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.getStyleClass().add("register-field");

        passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("register-field");

        confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");
        confirmPasswordField.getStyleClass().add("register-field");

        nameField = new TextField();
        nameField.setPromptText("Full Name");
        nameField.getStyleClass().add("register-field");

        emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("register-field");

        phoneField = new TextField();
        phoneField.setPromptText("Phone");
        phoneField.getStyleClass().add("register-field");

        roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll(UserRole.values());
        roleComboBox.setPromptText("Select Role");
        roleComboBox.getStyleClass().add("register-field");

        sectorComboBox = new ComboBox<>();
        sectorComboBox.setPromptText("Select Sector");
        sectorComboBox.getStyleClass().add("register-field");
        sectorComboBox.setVisible(false);

        createSectorButton = new Button("Create New Sector");
        createSectorButton.getStyleClass().addAll("button", "secondary");
        createSectorButton.setVisible(false);

        // Buttons container
        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.CENTER);

        registerButton = new Button("Register");
        registerButton.getStyleClass().addAll("button", "register-button");

        backToLoginButton = new Button("Back to Login");
        backToLoginButton.getStyleClass().addAll("button", "secondary");

        buttonsBox.getChildren().addAll(registerButton, backToLoginButton);

        errorText = new Text();
        errorText.getStyleClass().add("error-text");
        errorText.setVisible(false);

        // Add all components to form
        VBox formBox = new VBox(15);
        formBox.setAlignment(Pos.CENTER);
        formBox.getStyleClass().add("register-form");
        formBox.getChildren().addAll(
                title,
                usernameField,
                passwordField,
                confirmPasswordField,
                nameField,
                emailField,
                phoneField,
                roleComboBox,
                sectorComboBox,
                createSectorButton,
                buttonsBox,
                errorText
        );

        view.getChildren().add(formBox);
        rootPane.getChildren().add(view);

        setupEventHandlers();
        checkForInitialSetup();
        updateSectorComboBox();
    }

    private void setupEventHandlers() {
        roleComboBox.setOnAction(e -> handleRoleSelection());
        registerButton.setOnAction(e -> handleRegistration());
        backToLoginButton.setOnAction(e -> showLoginView());
        createSectorButton.setOnAction(e -> showCreateSectorDialog());
    }

    private void checkForInitialSetup() {
        System.out.println("Checking for initial setup");
        try {
            if (userController.getAllUsers().isEmpty()) {
                // Create default admin account
                User user = userController.createUser(
                        "admin",
                        "Admin@123",
                        "System Administrator",
                        "admin@store.com",
                        "0000000000",
                        UserRole.ADMINISTRATOR,
                        null
                );

                if (user != null) {
                    AlertDialog.showSuccess("Admin account created successfully:: username = admin || password = Admin@123");
                }
            }
        } catch (Exception e) {
            showError("Error during initial setup: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleRoleSelection() {
        UserRole selectedRole = roleComboBox.getValue();
        boolean needsSector = selectedRole == UserRole.CASHIER || selectedRole == UserRole.MANAGER;
        sectorComboBox.setVisible(needsSector);
        createSectorButton.setVisible(needsSector);

        if (needsSector) {
            updateSectorComboBox();
        }
    }

    private void updateSectorComboBox() {
        sectorComboBox.getItems().clear();
        sectorComboBox.getItems().addAll(sectorController.getActiveSectors());
    }

    private void showCreateSectorDialog() {
        Dialog<Sector> dialog = new Dialog<>();
        dialog.setTitle("Create New Sector");
        dialog.setHeaderText("Enter sector details");

        ButtonType createButtonType = new ButtonType("Create", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(createButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nameField = new TextField();
        nameField.setPromptText("Sector Name");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == createButtonType) {
                try {
                    return sectorController.createSector(
                            nameField.getText(),
                            descriptionField.getText()
                    );
                } catch (IOException e) {
                    showError("Error creating sector: " + e.getMessage());
                }
            }
            return null;
        });

        Optional<Sector> result = dialog.showAndWait();
        result.ifPresent(sector -> {
            updateSectorComboBox();
            sectorComboBox.setValue(sector);
        });
    }

    private void handleRegistration() {
        try {
            if (!passwordField.getText().equals(confirmPasswordField.getText())) {
                throw new IllegalArgumentException("Passwords do not match");
            }

            UserRole selectedRole = roleComboBox.getValue();
            if (selectedRole == null) {
                throw new IllegalArgumentException("Please select a role");
            }

            Integer sectorId = null;
            if ((selectedRole == UserRole.CASHIER || selectedRole == UserRole.MANAGER)
                    && sectorComboBox.getValue() != null) {
                sectorId = sectorComboBox.getValue().getId();
            }

            if (sectorId == null && (selectedRole == UserRole.CASHIER || selectedRole == UserRole.MANAGER)) {
                throw new IllegalArgumentException("Please select a sector");
            }

            userController.createUser(
                    usernameField.getText(),
                    passwordField.getText(),
                    nameField.getText(),
                    emailField.getText(),
                    phoneField.getText(),
                    selectedRole,
                    sectorId
            );

            showSuccessDialog();
            showLoginView();

        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void showSuccessDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("User registered successfully!");
        alert.showAndWait();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisible(true);
    }

    private void showLoginView() {
        LoginView loginView = new LoginView();
        Scene scene = new Scene(loginView.getView());
        scene.getStylesheets().add("/styles/style.css");
        App.getPrimaryStage().setScene(scene);
    }

    public StackPane getView() {
        return rootPane;
    }
}