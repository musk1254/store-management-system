package com.store.view.dashboard;

import com.store.controller.InventoryController;
import com.store.controller.SectorController;
import com.store.controller.UserController;
import com.store.model.Sector;
import com.store.model.User;
import com.store.util.AlertDialog;
import com.store.util.SessionManager;
import com.store.view.ManageInventory;
import com.store.view.ManageSectors;
import com.store.view.ManageUsers;
import com.store.view.ManageSuppliers;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.control.ButtonBar.ButtonData;

import java.util.List;

public class AdminDashboard {
    private final VBox rootPane;
    private final User currentUser;
    private final UserController userController;
    private final InventoryController inventoryController;
    private final SectorController sectorController;

    public AdminDashboard(User currentUser) {
        this.currentUser = currentUser;
        this.userController = UserController.getInstance();
        this.inventoryController = InventoryController.getInstance();
        this.sectorController = SectorController.getInstance();

        rootPane = new VBox(20);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);
        rootPane.getStyleClass().add("admin-dashboard");

        setupDashboard();
    }

    private void setupDashboard() {
        // Header
        HBox header = createHeader();

        // Stats cards
        GridPane statsGrid = createStatsGrid();

        // Navigation menu
        TabPane navigationTabs = createNavigationTabs();

        rootPane.getChildren().addAll(header, statsGrid, navigationTabs);
    }

    private HBox createHeader() {
        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("dashboard-header");

        Text welcomeText = new Text("Welcome, " + currentUser.getName());
        welcomeText.getStyleClass().add("welcome-text");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().addAll("button-secondary");
        logoutButton.setOnAction(e -> handleLogout());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(welcomeText, spacer, logoutButton);
        return header;
    }

    private GridPane createStatsGrid() {
        GridPane statsGrid = new GridPane();
        statsGrid.setHgap(10);
        statsGrid.setVgap(10);
        statsGrid.getStyleClass().add("stats-grid");

        // User stats
        var userStats = userController.getUserStats();
        createStatCard(statsGrid, "Total Users", userStats.get("totalUsers").toString(), 0, 0);
        createStatCard(statsGrid, "Active Users", userStats.get("activeUsers").toString(), 0, 1);
        createStatCard(statsGrid, "Cashiers", userStats.get("cashiers").toString(), 0, 2);
        createStatCard(statsGrid, "Managers", userStats.get("managers").toString(), 0, 3);

        // Inventory stats
        var inventoryReport = inventoryController.getInventoryReport();
        createStatCard(statsGrid, "Total Items",
                inventoryReport.get("totalItems").toString(), 0, 4);
        createStatCard(statsGrid, "Low Stock Items",
                inventoryReport.get("lowStockItems").toString(), 0, 5);
        createStatCard(statsGrid, "Total Value",
                String.format("$%.2f", inventoryReport.get("totalInventoryValue")), 0, 6);

        List<Sector> allSectors = sectorController.getAllSectors();
        List<Sector> activeSectors = sectorController.getActiveSectors();
        createStatCard(statsGrid, "Total Sectors", String.valueOf(allSectors.size()), 0, 7);
        createStatCard(statsGrid, "Active Sectors", String.valueOf(activeSectors.size()), 0, 8);

        return statsGrid;
    }

    private void createStatCard(GridPane parent, String title, String value, int row, int col) {
        VBox card = new VBox(5);
        card.getStyleClass().add("stat-card");
        card.setPadding(new Insets(15));

        Text titleText = new Text(title);
        titleText.getStyleClass().add("stat-title");

        Text valueText = new Text(value);
        valueText.getStyleClass().add("stat-value");

        card.getChildren().addAll(titleText, valueText);
        parent.add(card, col, row);
    }

    private TabPane createNavigationTabs() {
        TabPane tabPane = new TabPane();
        tabPane.getStyleClass().add("navigation-tabs");
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Users tab
        Tab usersTab = new Tab("User Management");
        usersTab.setContent(new ManageUsers().getView());

        // Sectors tab
        Tab sectorsTab = new Tab("Sector Management");
        sectorsTab.setContent(new ManageSectors().getView());

        // Inventory tab
        Tab inventoryTab = new Tab("Inventory Management");
        inventoryTab.setContent(new ManageInventory().getView());

        // Suppliers tab
        Tab suppliersTab = new Tab("Supplier Management");
        suppliersTab.setContent(new ManageSuppliers().getView());

        tabPane.getTabs().addAll(usersTab, sectorsTab, inventoryTab, suppliersTab);
        return tabPane;
    }

    private void handleLogout() {
        if (AlertDialog.showConfirm("Are you sure you want to logout?")) {
            SessionManager.getInstance().endSession();
        }
    }

    private void handleBackup() {
        try {
            userController.backup();
            inventoryController.synchronizeInventory();
            AlertDialog.showSuccess("System backup completed successfully");
        } catch (Exception e) {
            AlertDialog.showError("Backup failed: " + e.getMessage());
        }
    }

    private void handleMaintenance() {
        try {
            inventoryController.performInventoryMaintenance();
            AlertDialog.showSuccess("System maintenance completed successfully");
        } catch (Exception e) {
            AlertDialog.showError("Maintenance failed: " + e.getMessage());
        }
    }

    public VBox getView() {
        return rootPane;
    }
}