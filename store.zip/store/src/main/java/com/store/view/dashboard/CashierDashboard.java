package com.store.view.dashboard;

import com.store.controller.BillController;
import com.store.controller.UserController;
import com.store.model.Bill;
import com.store.model.Cashier;
import com.store.model.Item;
import com.store.model.User;
import com.store.util.AlertDialog;
import com.store.util.SessionManager;
import com.store.view.BillView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CashierDashboard {
    private final VBox rootPane;
    private final Cashier currentUser;
    private final BillController billController;
    private final BillView billView;
    private TableView<Bill> historyTable;
    private final ObservableList<Bill> historyBills = FXCollections.observableArrayList();
    private VBox summaryBox;
    private Text totalBillsValue;
    private Text totalAmountValue;
    private Text averageAmountValue;

    public CashierDashboard(User user) {
        this.currentUser = (Cashier) user;
        this.billController = BillController.getInstance();
        this.billView = new BillView();

        rootPane = new VBox(20);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);
        rootPane.getStyleClass().add("cashier-dashboard");

        setupDashboard();
    }

    private void setupDashboard() {
        HBox header = createHeader();
        GridPane statsGrid = createStatsGrid();
        TabPane contentTabs = createContentTabs();
        rootPane.getChildren().addAll(header, statsGrid, contentTabs);
    }

    private HBox createHeader() {
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("dashboard-header");

        Text welcomeText = new Text("Welcome, " + currentUser.getName());
        welcomeText.getStyleClass().add("welcome-text");

        Text sectorInfo = new Text("Sector: " + currentUser.getSectorId());
        sectorInfo.getStyleClass().add("sector-info");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().addAll("button-secondary");
        logoutButton.setOnAction(e -> handleLogout());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(welcomeText, sectorInfo, spacer, logoutButton);
        return header;
    }

    private GridPane createStatsGrid() {
        GridPane statsGrid = new GridPane();
        statsGrid.setHgap(10);
        statsGrid.setVgap(10);

        // Today's stats
        LocalDateTime startOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDateTime endOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);

        List<Bill> todaysBills = billController.getBillsByDateRange(startOfDay, endOfDay);
        double todaysRevenue = billController.calculateTotalRevenue(startOfDay, endOfDay);

        // Create stat cards
        createStatCard(statsGrid, "Today's Bills", String.valueOf(todaysBills.size()), 0, 0);
        createStatCard(statsGrid, "Today's Revenue", String.format("$%.2f", todaysRevenue), 0, 1);
        createStatCard(statsGrid, "Average Bill Value",
                String.format("$%.2f", todaysBills.isEmpty() ? 0 : todaysRevenue / todaysBills.size()), 0, 2);

        // Get top selling items
        Map<Item, Integer> topItems = billController.getTopSellingItems(5);
        if (!topItems.isEmpty()) {
            Map.Entry<Item, Integer> topItem = topItems.entrySet().iterator().next();
            createStatCard(statsGrid, "Top Selling Item",
                    topItem.getKey().getName() + " (" + topItem.getValue() + ")", 0, 3);
        }

        return statsGrid;
    }

    private void createStatCard(GridPane parent, String title, String value, int row, int col) {
        VBox card = new VBox(5);
        card.getStyleClass().add("stat-card");
        card.setPadding(new Insets(15));

        Text titleText = new Text(title);
        titleText.getStyleClass().add("stat-title");

        Text valueText = new Text(value);
        valueText.getStyleClass().add("stat-value");

        card.getChildren().addAll(titleText, valueText);
        parent.add(card, col, row);
    }

    private TabPane createContentTabs() {
        TabPane tabPane = new TabPane();
        tabPane.getStyleClass().add("navigation-tabs");
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Bills tab
        Tab billsTab = new Tab("Bills Management");
        billsTab.setContent(billView.getView());

        // History tab
        Tab historyTab = new Tab("Bill History");
        historyTab.setContent(createBillHistory());

        // Reports tab
        Tab reportsTab = new Tab("Daily Reports");
        reportsTab.setContent(createReportsView());

        tabPane.getTabs().addAll(billsTab, historyTab, reportsTab);
        return tabPane;
    }

    private VBox createBillHistory() {
        VBox historyView = new VBox(20);
        historyView.setPadding(new Insets(20));
        historyView.getStyleClass().add("history-view");

        // Date picker for filtering
        DatePicker datePicker = new DatePicker(LocalDate.now());

        // Search and filter section
        HBox filterBox = new HBox(10);
        filterBox.setAlignment(Pos.CENTER_LEFT);

        TextField searchField = new TextField();
        searchField.setPromptText("Search bills...");
        searchField.setPrefWidth(200);

        Button refreshButton = new Button("Refresh");
        refreshButton.getStyleClass().add("button");
        refreshButton.setOnAction(e -> updateBillHistory(datePicker.getValue()));

        filterBox.getChildren().addAll(
                new Label("Select Date:"),
                datePicker,
                searchField,
                refreshButton
        );

        // Initialize and setup the table
        historyTable = new TableView<>(historyBills);
        historyTable.getStyleClass().add("bills-table");
        historyTable.setPlaceholder(new Label("No bills found for the selected date"));

        // Configure table columns
        TableColumn<Bill, String> billNumberCol = new TableColumn<>("Bill Number");
        billNumberCol.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getBillNumber()));
        billNumberCol.setPrefWidth(150);

        TableColumn<Bill, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getSaleDate().format(
                        DateTimeFormatter.ofPattern("HH:mm:ss"))));
        timeCol.setPrefWidth(100);

        TableColumn<Bill, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("$%.2f",
                        data.getValue().calculateTotal())));
        totalCol.setPrefWidth(100);

        TableColumn<Bill, String> itemsCol = new TableColumn<>("Items");
        itemsCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.valueOf(
                        data.getValue().getItems().size())));
        itemsCol.setPrefWidth(80);

        TableColumn<Bill, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().isFinalized() ?
                        "Finalized" : "Pending"));
        statusCol.setPrefWidth(100);

        historyTable.getColumns().addAll(
                billNumberCol,
                timeCol,
                totalCol,
                itemsCol,
                statusCol
        );

        // Add context menu for actions
        ContextMenu contextMenu = new ContextMenu();
        MenuItem viewDetailsItem = new MenuItem("View Details");
        MenuItem printBillItem = new MenuItem("Print Bill");

        viewDetailsItem.setOnAction(e -> showBillDetails(
                historyTable.getSelectionModel().getSelectedItem()));
        printBillItem.setOnAction(e -> printBill(
                historyTable.getSelectionModel().getSelectedItem()));

        contextMenu.getItems().addAll(viewDetailsItem, printBillItem);
        historyTable.setContextMenu(contextMenu);

        // Add search functionality
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                updateBillHistory(datePicker.getValue());
            } else {
                filterBills(newValue.toLowerCase(), datePicker.getValue());
            }
        });

        datePicker.setOnAction(e -> updateBillHistory(datePicker.getValue()));

        // Summary section
        VBox summaryBox = createHistorySummary();

        historyView.getChildren().addAll(filterBox, historyTable, summaryBox);

        // Initial load
        updateBillHistory(LocalDate.now());

        return historyView;
    }

    private void updateBillHistory(LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.atTime(LocalTime.MAX);

        try {
            List<Bill> bills = billController.getBillsByDateRange(start, end)
                    .stream()
                    .filter(bill -> bill.getCashierId().equals(currentUser.getId()))
                    .sorted(Comparator.comparing(Bill::getSaleDate).reversed())
                    .collect(Collectors.toList());

            historyBills.setAll(bills);
            updateHistorySummary(bills);
        } catch (Exception e) {
            AlertDialog.showError("Error loading bills: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void filterBills(String searchText, LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.atTime(LocalTime.MAX);

        try {
            List<Bill> bills = billController.getBillsByDateRange(start, end)
                    .stream()
                    .filter(bill -> bill.getCashierId().equals(currentUser.getId()))
                    .filter(bill ->
                            bill.getBillNumber().toLowerCase().contains(searchText) ||
                                    String.format("%.2f", bill.calculateTotal()).contains(searchText))
                    .sorted(Comparator.comparing(Bill::getSaleDate).reversed())
                    .collect(Collectors.toList());

            historyBills.setAll(bills);
            updateHistorySummary(bills);
        } catch (Exception e) {
            AlertDialog.showError("Error filtering bills: " + e.getMessage());
        }
    }

    private VBox createHistorySummary() {
        summaryBox = new VBox(10);
        summaryBox.getStyleClass().add("summary-box");
        summaryBox.setPadding(new Insets(10));

        GridPane summaryGrid = new GridPane();
        summaryGrid.setHgap(20);
        summaryGrid.setVgap(5);
        summaryGrid.getStyleClass().add("summary-grid");

        Text totalBillsLabel = new Text("Total Bills:");
        Text totalAmountLabel = new Text("Total Amount:");
        Text averageAmountLabel = new Text("Average Amount:");

        totalBillsValue = new Text("0");
        totalAmountValue = new Text("$0.00");
        averageAmountValue = new Text("$0.00");

        // Remove the ID assignments since we'll use direct references
        summaryGrid.addRow(0, totalBillsLabel, totalBillsValue);
        summaryGrid.addRow(1, totalAmountLabel, totalAmountValue);
        summaryGrid.addRow(2, averageAmountLabel, averageAmountValue);

        summaryBox.getChildren().add(summaryGrid);
        return summaryBox;
    }

    private void updateHistorySummary(List<Bill> bills) {
        if (totalBillsValue != null && totalAmountValue != null && averageAmountValue != null) {
            int totalBills = bills.size();
            double totalAmount = bills.stream()
                    .mapToDouble(Bill::calculateTotal)
                    .sum();
            double averageAmount = totalBills > 0 ? totalAmount / totalBills : 0;

            // Update the Text nodes directly
            totalBillsValue.setText(String.valueOf(totalBills));
            totalAmountValue.setText(String.format("$%.2f", totalAmount));
            averageAmountValue.setText(String.format("$%.2f", averageAmount));
        }
    }

    private void showBillDetails(Bill bill) {
        if (bill == null) return;

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Bill Details");
        dialog.setHeaderText("Bill Number: " + bill.getBillNumber());

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        // Create items table
        TableView<Map.Entry<Item, Integer>> itemsTable = new TableView<>();

        TableColumn<Map.Entry<Item, Integer>, String> nameCol = new TableColumn<>("Item");
        nameCol.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getKey().getName()));

        TableColumn<Map.Entry<Item, Integer>, String> quantityCol = new TableColumn<>("Quantity");
        quantityCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.valueOf(data.getValue().getValue())));

        TableColumn<Map.Entry<Item, Integer>, String> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("$%.2f",
                        data.getValue().getKey().getSellingPrice())));

        TableColumn<Map.Entry<Item, Integer>, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(data ->
                new SimpleStringProperty(String.format("$%.2f",
                        data.getValue().getKey().getSellingPrice() * data.getValue().getValue())));

        itemsTable.getColumns().addAll(nameCol, quantityCol, priceCol, totalCol);
        itemsTable.getItems().addAll(bill.getItems().entrySet());

        content.getChildren().addAll(
                new Text("Date: " + bill.getSaleDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))),
                new Text("Status: " + (bill.isFinalized() ? "Finalized" : "Pending")),
                new Text("Total Amount: $" + String.format("%.2f", bill.calculateTotal())),
                new Separator(),
                itemsTable
        );

        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    private void printBill(Bill bill) {
        if (bill == null) return;

        try {
            String printableContent = billController.printBill(bill.getBillNumber());
            Dialog<Void> dialog = new Dialog<>();
            dialog.setTitle("Print Preview");
            dialog.setHeaderText(null);

            TextArea textArea = new TextArea(printableContent);
            textArea.setEditable(false);
            textArea.setPrefRowCount(20);
            textArea.setPrefColumnCount(50);
            textArea.setFont(javafx.scene.text.Font.font("Monospace"));

            dialog.getDialogPane().setContent(textArea);
            dialog.getDialogPane().getButtonTypes().addAll(
                    new ButtonType("Print", ButtonBar.ButtonData.OK_DONE),
                    ButtonType.CLOSE
            );

            dialog.showAndWait();
        } catch (Exception e) {
            AlertDialog.showError("Error printing bill: " + e.getMessage());
        }
    }

    private VBox createReportsView() {
        VBox reportsView = new VBox(20);
        reportsView.setPadding(new Insets(20));
        reportsView.getStyleClass().add("reports-view");

        // Daily summary
        Text summaryTitle = new Text("Daily Summary");
        summaryTitle.getStyleClass().add("section-title");

        GridPane summaryGrid = new GridPane();
        summaryGrid.setHgap(10);
        summaryGrid.setVgap(10);
        summaryGrid.getStyleClass().add("summary-grid");

        // Get daily statistics
        LocalDateTime startOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDateTime endOfDay = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        Map<String, Object> dailyStats = billController.getBillStatistics(startOfDay, endOfDay);

        // Create summary cards
        int row = 0;
        for (Map.Entry<String, Object> stat : dailyStats.entrySet()) {
            Label label = new Label(formatStatLabel(stat.getKey()) + ":");
            label.getStyleClass().add("stat-label");

            Text value = new Text(formatStatValue(stat.getValue()));
            value.getStyleClass().add("stat-value");

            summaryGrid.add(label, 0, row);
            summaryGrid.add(value, 1, row);
            row++;
        }

        reportsView.getChildren().addAll(summaryTitle, summaryGrid);
        return reportsView;
    }

    private String formatStatLabel(String key) {
        return key.replaceAll("([A-Z])", " $1")
                .substring(0, 1).toUpperCase() +
                key.replaceAll("([A-Z])", " $1").substring(1);
    }

    private String formatStatValue(Object value) {
        if (value instanceof Double) {
            return String.format("$%.2f", (Double) value);
        }
        return value.toString();
    }

    private void handleLogout() {
        if (AlertDialog.showConfirm("Are you sure you want to logout?")) {
            SessionManager.getInstance().endSession();
        }
    }

    public VBox getView() {
        return rootPane;
    }
}