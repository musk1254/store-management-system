package com.store.view.dashboard;

import com.store.controller.*;
import com.store.model.*;
import com.store.util.AlertDialog;
import com.store.util.SessionManager;
import com.store.view.ManageInventory;
import com.store.view.ManageSuppliers;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.util.List;
import java.util.stream.Collectors;

public class ManagerDashboard {
    private final VBox rootPane;
    private final Manager currentUser;
    private final ItemController itemController;
    private final BillController billController;
    private final SectorController sectorController;

    public ManagerDashboard(User user) {
        this.currentUser = (Manager) user;
        this.itemController = ItemController.getInstance();
        this.billController = BillController.getInstance();
        this.sectorController = SectorController.getInstance();

        rootPane = new VBox(20);
        rootPane.setPadding(new Insets(20));
        rootPane.setAlignment(Pos.TOP_CENTER);
        rootPane.getStyleClass().add("manager-dashboard");

        setupDashboard();
        checkLowStockItems(); // Initial stock check
    }

    private void setupDashboard() {
        // Header with welcome message and logout button
        HBox header = createHeader();

        // Main content tabs
        TabPane contentTabs = createContentTabs();

        rootPane.getChildren().addAll(header, contentTabs);
    }

    private HBox createHeader() {
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("dashboard-header");

        Text welcomeText = new Text("Welcome, " + currentUser.getName());
        welcomeText.getStyleClass().add("welcome-text");

        String sectorNames = currentUser.getManagedSectors().stream()
                .map(sectorId -> sectorController.getSector(sectorId)
                        .map(Sector::getName)
                        .orElse("Unknown Sector"))
                .collect(Collectors.joining(", "));
        Text sectorInfo = new Text("Managing Sectors: " + sectorNames);
        sectorInfo.getStyleClass().add("sector-info");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("button-secondary");
        logoutButton.setOnAction(e -> handleLogout());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(welcomeText, sectorInfo, spacer, logoutButton);
        return header;
    }

    private TabPane createContentTabs() {
        TabPane tabPane = new TabPane();
        tabPane.getStyleClass().add("navigation-tabs");
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Inventory Management tab
        Tab inventoryTab = new Tab("Inventory Management");
        inventoryTab.setContent(new ManageInventory().getView());

        // Supplier Management tab
        Tab suppliersTab = new Tab("Supplier Management");
        suppliersTab.setContent(new ManageSuppliers().getView());

        tabPane.getTabs().addAll(inventoryTab, suppliersTab);
        return tabPane;
    }

    private void checkLowStockItems() {
        List<Item> lowStockItems = itemController.getLowStockItems(5);
        if (!lowStockItems.isEmpty()) {
            StringBuilder message = new StringBuilder("Low stock alert:\n");
            lowStockItems.forEach(item ->
                    message.append(String.format("- %s (Quantity: %d)\n",
                            item.getName(), item.getQuantity())));
            AlertDialog.showWarning(message.toString());
        }
    }

    private void handleLogout() {
        if (AlertDialog.showConfirm("Are you sure you want to logout?")) {
            SessionManager.getInstance().endSession();
        }
    }

    public VBox getView() {
        return rootPane;
    }
}